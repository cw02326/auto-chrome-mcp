import { n as init_asyncToGenerator, t as _asyncToGenerator } from "./asyncToGenerator-D0fCMItH.js";
import { H as withDirectives, Z as ref, at as toDisplayString, b as defineComponent, d as computed, f as createBaseVNode, h as createElementBlock, i as vModelCheckbox, j as openBlock, nt as unref, r as createApp, t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-WBN59Mux.js";
/* empty css                  */
/* empty css                    */
//#region entrypoints/consent/App.vue?vue&type=script&setup=true&lang.ts
init_asyncToGenerator();
var _hoisted_1 = { class: "consent-root" };
var _hoisted_2 = { class: "consent-card" };
var _hoisted_3 = { class: "consent-header" };
var _hoisted_4 = {
	class: "consent-icon",
	"aria-hidden": "true"
};
var _hoisted_5 = { class: "consent-title" };
var _hoisted_6 = { class: "consent-body" };
var _hoisted_7 = { class: "consent-row" };
var _hoisted_8 = { class: "consent-value" };
var _hoisted_9 = { class: "consent-row" };
var _hoisted_10 = { class: "consent-value consent-origin" };
var _hoisted_11 = { class: "consent-remember" };
var _hoisted_12 = { class: "consent-actions" };
var _hoisted_13 = ["disabled"];
var _hoisted_14 = ["disabled"];
//#endregion
//#region entrypoints/consent/main.ts
createApp(/* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "App",
	setup(__props) {
		const params = new URLSearchParams(window.location.search);
		const requestId = params.get("id") || "";
		const action = params.get("action") || "camera";
		const reason = params.get("reason") || "(이유 없음)";
		const origin = params.get("origin") || "(unknown)";
		const ICONS = {
			camera: "📷",
			microphone: "🎤",
			geolocation: "📍"
		};
		const LABELS = {
			camera: "카메라 사용",
			microphone: "마이크 사용",
			geolocation: "위치 정보 사용"
		};
		const icon = computed(() => ICONS[action] || "🔒");
		const label = computed(() => LABELS[action] || action);
		const rememberCheck = ref(false);
		const sending = ref(false);
		function respond(_x) {
			return _respond.apply(this, arguments);
		}
		function _respond() {
			_respond = _asyncToGenerator(function* (approved) {
				if (sending.value) return;
				sending.value = true;
				try {
					yield chrome.runtime.sendMessage({
						type: "CONSENT_RESPONSE",
						id: requestId,
						approved,
						remember: approved && rememberCheck.value
					});
				} catch (e) {
					console.error("[consent] send response failed:", e);
				} finally {
					window.close();
				}
			});
			return _respond.apply(this, arguments);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [
				createBaseVNode("header", _hoisted_3, [createBaseVNode("span", _hoisted_4, toDisplayString(icon.value), 1), createBaseVNode("h1", _hoisted_5, toDisplayString(label.value) + " 요청", 1)]),
				createBaseVNode("div", _hoisted_6, [createBaseVNode("div", _hoisted_7, [_cache[3] || (_cache[3] = createBaseVNode("span", { class: "consent-label" }, "이유", -1)), createBaseVNode("span", _hoisted_8, toDisplayString(unref(reason)), 1)]), createBaseVNode("div", _hoisted_9, [_cache[4] || (_cache[4] = createBaseVNode("span", { class: "consent-label" }, "사이트", -1)), createBaseVNode("span", _hoisted_10, toDisplayString(unref(origin)), 1)])]),
				createBaseVNode("label", _hoisted_11, [withDirectives(createBaseVNode("input", {
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => rememberCheck.value = $event),
					type: "checkbox"
				}, null, 512), [[vModelCheckbox, rememberCheck.value]]), _cache[5] || (_cache[5] = createBaseVNode("span", null, "다음부터 묻지 않기 (토글 ON)", -1))]),
				createBaseVNode("footer", _hoisted_12, [createBaseVNode("button", {
					class: "consent-btn consent-btn--deny",
					disabled: sending.value,
					onClick: _cache[1] || (_cache[1] = ($event) => respond(false))
				}, " 거부 ", 8, _hoisted_13), createBaseVNode("button", {
					class: "consent-btn consent-btn--allow",
					disabled: sending.value,
					onClick: _cache[2] || (_cache[2] = ($event) => respond(true))
				}, " 이번만 허용 ", 8, _hoisted_14)])
			])]);
		};
	}
}), [["__scopeId", "data-v-9bbf6bf6"]])).mount("#app");
//#endregion
