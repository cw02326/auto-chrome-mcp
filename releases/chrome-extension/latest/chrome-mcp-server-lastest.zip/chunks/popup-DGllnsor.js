import { n as init_asyncToGenerator, t as _asyncToGenerator } from "./asyncToGenerator-D0fCMItH.js";
import { A as onUnmounted, H as withDirectives, N as renderList, V as withCtx, Z as ref, at as toDisplayString, b as defineComponent, c as withModifiers, d as computed, f as createBaseVNode, h as createElementBlock, j as openBlock, k as onMounted, l as Fragment, m as createCommentVNode, n as Transition, nt as unref, p as createBlock, r as createApp, rt as normalizeClass, s as vShow, t as _plugin_vue_export_helper_default, v as createTextVNode, y as createVNode } from "./_plugin-vue_export-helper-WBN59Mux.js";
import { t as _objectSpread2 } from "./objectSpread2-cFYd0E9o.js";
import { n as NativeMessageType } from "./dist-j-e5vP91.js";
import { t as BACKGROUND_MESSAGE_TYPES } from "./message-types-68mai8gF.js";
/* empty css                    */
import { a as getCacheStats, i as clearModelCache, o as getModelInfo, r as cleanupModelCache, t as PREDEFINED_MODELS } from "./semantic-similarity-engine-DettBozR.js";
import { n as useAgentTheme, t as preloadAgentTheme } from "./useAgentTheme-DKfIq6SK.js";
//#region utils/i18n.ts
init_asyncToGenerator();
/**
* Chrome Extension i18n utility
* Provides safe access to chrome.i18n.getMessage with fallbacks
*/
var fallbackMessages = {
	extensionName: "chrome-mcp-server",
	extensionDescription: "Exposes browser capabilities with your own chrome",
	nativeServerConfigLabel: "Native Server Configuration",
	semanticEngineLabel: "Semantic Engine",
	embeddingModelLabel: "Embedding Model",
	indexDataManagementLabel: "Index Data Management",
	modelCacheManagementLabel: "Model Cache Management",
	statusLabel: "Status",
	runningStatusLabel: "Running Status",
	connectionStatusLabel: "Connection Status",
	lastUpdatedLabel: "Last Updated:",
	connectButton: "Connect",
	disconnectButton: "Disconnect",
	connectingStatus: "Connecting...",
	connectedStatus: "Connected",
	disconnectedStatus: "Disconnected",
	detectingStatus: "Detecting...",
	serviceRunningStatus: "Service Running (Port: {0})",
	serviceNotConnectedStatus: "Service Not Connected",
	connectedServiceNotStartedStatus: "Connected, Service Not Started",
	mcpServerConfigLabel: "MCP Server Configuration",
	connectionPortLabel: "Connection Port",
	refreshStatusButton: "Refresh Status",
	copyConfigButton: "Copy Configuration",
	retryButton: "Retry",
	cancelButton: "Cancel",
	confirmButton: "Confirm",
	saveButton: "Save",
	closeButton: "Close",
	resetButton: "Reset",
	initializingStatus: "Initializing...",
	processingStatus: "Processing...",
	loadingStatus: "Loading...",
	clearingStatus: "Clearing...",
	cleaningStatus: "Cleaning...",
	downloadingStatus: "Downloading...",
	semanticEngineReadyStatus: "Semantic Engine Ready",
	semanticEngineInitializingStatus: "Semantic Engine Initializing...",
	semanticEngineInitFailedStatus: "Semantic Engine Initialization Failed",
	semanticEngineNotInitStatus: "Semantic Engine Not Initialized",
	initSemanticEngineButton: "Initialize Semantic Engine",
	reinitializeButton: "Reinitialize",
	downloadingModelStatus: "Downloading Model... {0}%",
	switchingModelStatus: "Switching Model...",
	modelLoadedStatus: "Model Loaded",
	modelFailedStatus: "Model Failed to Load",
	lightweightModelDescription: "Lightweight Multilingual Model",
	betterThanSmallDescription: "Slightly larger than e5-small, but better performance",
	multilingualModelDescription: "Multilingual Semantic Model",
	fastPerformance: "Fast",
	balancedPerformance: "Balanced",
	accuratePerformance: "Accurate",
	networkErrorMessage: "Network connection error, please check network and retry",
	modelCorruptedErrorMessage: "Model file corrupted or incomplete, please retry download",
	unknownErrorMessage: "Unknown error, please check if your network can access HuggingFace",
	permissionDeniedErrorMessage: "Permission denied",
	timeoutErrorMessage: "Operation timed out",
	indexedPagesLabel: "Indexed Pages",
	indexSizeLabel: "Index Size",
	activeTabsLabel: "Active Tabs",
	vectorDocumentsLabel: "Vector Documents",
	cacheSizeLabel: "Cache Size",
	cacheEntriesLabel: "Cache Entries",
	clearAllDataButton: "Clear All Data",
	clearAllCacheButton: "Clear All Cache",
	cleanExpiredCacheButton: "Clean Expired Cache",
	exportDataButton: "Export Data",
	importDataButton: "Import Data",
	confirmClearDataTitle: "Confirm Clear Data",
	settingsTitle: "Settings",
	aboutTitle: "About",
	helpTitle: "Help",
	clearDataWarningMessage: "This operation will clear all indexed webpage content and vector data, including:",
	clearDataList1: "All webpage text content index",
	clearDataList2: "Vector embedding data",
	clearDataList3: "Search history and cache",
	clearDataIrreversibleWarning: "This operation is irreversible! After clearing, you need to browse webpages again to rebuild the index.",
	confirmClearButton: "Confirm Clear",
	cacheDetailsLabel: "Cache Details",
	noCacheDataMessage: "No cache data",
	loadingCacheInfoStatus: "Loading cache information...",
	processingCacheStatus: "Processing cache...",
	expiredLabel: "Expired",
	bookmarksBarLabel: "Bookmarks Bar",
	newTabLabel: "New Tab",
	currentPageLabel: "Current Page",
	menuLabel: "Menu",
	navigationLabel: "Navigation",
	mainContentLabel: "Main Content",
	languageSelectorLabel: "Language",
	themeLabel: "Theme",
	lightTheme: "Light",
	darkTheme: "Dark",
	autoTheme: "Auto",
	advancedSettingsLabel: "Advanced Settings",
	debugModeLabel: "Debug Mode",
	verboseLoggingLabel: "Verbose Logging",
	successNotification: "Operation completed successfully",
	warningNotification: "Warning: Please review before proceeding",
	infoNotification: "Information",
	configCopiedNotification: "Configuration copied to clipboard",
	dataClearedNotification: "Data cleared successfully",
	bytesUnit: "bytes",
	kilobytesUnit: "KB",
	megabytesUnit: "MB",
	gigabytesUnit: "GB",
	itemsUnit: "items",
	pagesUnit: "pages",
	nativeServerConfig: "Native Server Configuration",
	runningStatus: "Running Status",
	refreshStatus: "Refresh Status",
	lastUpdated: "Last Updated:",
	mcpServerConfig: "MCP Server Configuration",
	connectionPort: "Connection Port",
	connecting: "Connecting...",
	disconnect: "Disconnect",
	connect: "Connect",
	semanticEngine: "Semantic Engine",
	embeddingModel: "Embedding Model",
	retry: "Retry",
	indexDataManagement: "Index Data Management",
	clearing: "Clearing...",
	clearAllData: "Clear All Data",
	copyConfig: "Copy Configuration",
	serviceRunning: "Service Running (Port: {0})",
	connectedServiceNotStarted: "Connected, Service Not Started",
	serviceNotConnected: "Service Not Connected",
	detecting: "Detecting...",
	lightweightModel: "Lightweight Multilingual Model",
	betterThanSmall: "Slightly larger than e5-small, but better performance",
	multilingualModel: "Multilingual Semantic Model",
	fast: "Fast",
	balanced: "Balanced",
	accurate: "Accurate",
	semanticEngineReady: "Semantic Engine Ready",
	semanticEngineInitializing: "Semantic Engine Initializing...",
	semanticEngineInitFailed: "Semantic Engine Initialization Failed",
	semanticEngineNotInit: "Semantic Engine Not Initialized",
	downloadingModel: "Downloading Model... {0}%",
	switchingModel: "Switching Model...",
	networkError: "Network connection error, please check network and retry",
	modelCorrupted: "Model file corrupted or incomplete, please retry download",
	unknownError: "Unknown error, please check if your network can access HuggingFace",
	reinitialize: "Reinitialize",
	initializing: "Initializing...",
	initSemanticEngine: "Initialize Semantic Engine",
	indexedPages: "Indexed Pages",
	indexSize: "Index Size",
	activeTabs: "Active Tabs",
	vectorDocuments: "Vector Documents",
	confirmClearData: "Confirm Clear Data",
	clearDataWarning: "This operation will clear all indexed webpage content and vector data, including:",
	clearDataIrreversible: "This operation is irreversible! After clearing, you need to browse webpages again to rebuild the index.",
	confirmClear: "Confirm Clear",
	cancel: "Cancel",
	confirm: "Confirm",
	processing: "Processing...",
	modelCacheManagement: "Model Cache Management",
	cacheSize: "Cache Size",
	cacheEntries: "Cache Entries",
	cacheDetails: "Cache Details",
	noCacheData: "No cache data",
	loadingCacheInfo: "Loading cache information...",
	processingCache: "Processing cache...",
	cleaning: "Cleaning...",
	cleanExpiredCache: "Clean Expired Cache",
	clearAllCache: "Clear All Cache",
	expired: "Expired",
	bookmarksBar: "Bookmarks Bar"
};
/**
* Safe i18n message getter with fallback support
* @param key Message key
* @param substitutions Optional substitution values
* @returns Localized message or fallback
*/
function getMessage(key, substitutions) {
	try {
		if (typeof chrome !== "undefined" && chrome.i18n && chrome.i18n.getMessage) {
			const message = chrome.i18n.getMessage(key, substitutions);
			if (message) return message;
		}
	} catch (error) {
		console.warn(`Failed to get i18n message for key "${key}":`, error);
	}
	let fallback = fallbackMessages[key] || key;
	if (substitutions && substitutions.length > 0) substitutions.forEach((value, index) => {
		fallback = fallback.replace(`{${index}}`, value);
	});
	return fallback;
}
//#endregion
//#region utils/focus-policy.ts
/**
* Force-focus policy gate (scalemaker fork).
*
* MCP 도구 실행 시 chrome.windows.update({focused: true}) 가 OS 레벨로 Chrome 윈도우를
* 다른 앱 앞으로 끌어내는 동작을 사용자가 popup 토글로 끌 수 있게 한다.
*
* 범위 — OS 윈도우 포커스만 게이트:
*   - chrome.windows.update({focused: true})    → 정책 OFF 면 호출 자체 skip
*   - chrome.windows.create({focused: true})    → 정책 OFF 면 focused: false 로 생성
* 범위 밖 (항상 호출):
*   - chrome.tabs.update({active: true})        → 같은 윈도우 내 탭 전환 (screenshot/click 동작에 필수)
*   - chrome.tabs.create({active: true})        → 새 탭 생성 + 활성화
*
* 기본값 false — 새로 설치하는 사용자는 강제 포커스 없음. 사용자가 명시적으로 ON 으로 토글해야 동작.
*/
var STORAGE_KEY$3 = "forceFocusOnToolCall";
function isForceFocusEnabled() {
	return _isForceFocusEnabled.apply(this, arguments);
}
function _isForceFocusEnabled() {
	_isForceFocusEnabled = _asyncToGenerator(function* () {
		try {
			return (yield chrome.storage.local.get([STORAGE_KEY$3]))[STORAGE_KEY$3] === true;
		} catch (_unused) {
			return false;
		}
	});
	return _isForceFocusEnabled.apply(this, arguments);
}
function setForceFocusEnabled(_x) {
	return _setForceFocusEnabled.apply(this, arguments);
}
function _setForceFocusEnabled() {
	_setForceFocusEnabled = _asyncToGenerator(function* (enabled) {
		yield chrome.storage.local.set({ [STORAGE_KEY$3]: enabled });
	});
	return _setForceFocusEnabled.apply(this, arguments);
}
//#endregion
//#region utils/background-mode.ts
init_asyncToGenerator();
/**
* Background work mode policy gate (scalemaker fork).
*
* ON 이면 MCP 도구 실행이 사용자의 브라우징을 방해하지 않는다:
*   - 도구 args 에 background 가 미지정이면 true 로 주입 (tools/index.ts handleCallTool 게이트)
*   - 도구 args 에 tabId 가 미지정이면 MCP 작업 탭(work-tab-manager)을 주입
*   - ensureFocus 의 tabs.update({active:true}) 를 skip (forceActivate 제외)
*
* 예외 도구 (게이트 미적용): chrome_switch_tab, chrome_request_element_selection,
* chrome_request_user_consent — 정의상 사용자 대면 동작.
*
* 기본값 true — 별도 설정 없이 무간섭 동작. popup 토글로 OFF 가능.
* OS 윈도우 포커스는 별도 정책 utils/focus-policy.ts 가 담당한다.
*/
var STORAGE_KEY$2 = "backgroundWorkMode";
function isBackgroundModeEnabled() {
	return _isBackgroundModeEnabled.apply(this, arguments);
}
function _isBackgroundModeEnabled() {
	_isBackgroundModeEnabled = _asyncToGenerator(function* () {
		try {
			return (yield chrome.storage.local.get([STORAGE_KEY$2]))[STORAGE_KEY$2] !== false;
		} catch (_unused) {
			return true;
		}
	});
	return _isBackgroundModeEnabled.apply(this, arguments);
}
function setBackgroundModeEnabled(_x) {
	return _setBackgroundModeEnabled.apply(this, arguments);
}
function _setBackgroundModeEnabled() {
	_setBackgroundModeEnabled = _asyncToGenerator(function* (enabled) {
		yield chrome.storage.local.set({ [STORAGE_KEY$2]: enabled });
	});
	return _setBackgroundModeEnabled.apply(this, arguments);
}
//#endregion
//#region utils/mcp-window-manager.ts
init_asyncToGenerator();
/**
* Dedicated MCP work window policy + tracker (scalemaker fork).
*
* 백그라운드 작업 모드가 ON 일 때, MCP 작업 탭들을 사용자의 창이 아니라 별도의
* "MCP 작업 창" 하나에 모아 둔다. 세션별 작업 탭(최대 10개, work-tab-manager)이
* 한 창에 모이므로 사용자의 브라우징과 물리적·시각적으로 분리된다.
*
* - 창은 항상 focused: false 로 생성 — OS 포커스를 절대 가로채지 않는다.
*   (강제 포커스 정책 utils/focus-policy.ts 와 무관하게 이 창 생성은 언제나 비포커스)
* - 창 id 는 chrome.storage.session 에 persist + in-memory 캐시
*   (MV3 service worker 가 수시로 죽으므로. 브라우저 재시작 시 초기화 — 의도된 수명)
* - 사용자가 이 창을 닫으면 onRemoved 로 기록을 지우고, 다음 요청 때 새로 만든다.
* - 모든 실패는 null 로 흘려보낸다 — 호출부는 반드시 기존(사용자 창) 동작으로 graceful fallback.
*
* 기본값 true — 별도 설정 없이 분리 동작. popup 토글로 OFF 가능.
*/
var STORAGE_KEY$1 = "dedicatedWorkWindow";
var SESSION_KEY = "mcpWorkWindowId";
function isDedicatedWindowEnabled() {
	return _isDedicatedWindowEnabled.apply(this, arguments);
}
function _isDedicatedWindowEnabled() {
	_isDedicatedWindowEnabled = _asyncToGenerator(function* () {
		try {
			return (yield chrome.storage.local.get([STORAGE_KEY$1]))[STORAGE_KEY$1] !== false;
		} catch (_unused) {
			return true;
		}
	});
	return _isDedicatedWindowEnabled.apply(this, arguments);
}
function setDedicatedWindowEnabled(_x) {
	return _setDedicatedWindowEnabled.apply(this, arguments);
}
function _setDedicatedWindowEnabled() {
	_setDedicatedWindowEnabled = _asyncToGenerator(function* (enabled) {
		yield chrome.storage.local.set({ [STORAGE_KEY$1]: enabled });
	});
	return _setDedicatedWindowEnabled.apply(this, arguments);
}
var cachedWindowId = null;
var cacheLoaded = false;
function loadCache() {
	return _loadCache.apply(this, arguments);
}
function _loadCache() {
	_loadCache = _asyncToGenerator(function* () {
		if (cacheLoaded) return cachedWindowId;
		try {
			const raw = (yield chrome.storage.session.get([SESSION_KEY]))[SESSION_KEY];
			cachedWindowId = typeof raw === "number" ? raw : null;
		} catch (_unused2) {
			cachedWindowId = null;
		}
		cacheLoaded = true;
		return cachedWindowId;
	});
	return _loadCache.apply(this, arguments);
}
function persistWindowId(_x2) {
	return _persistWindowId.apply(this, arguments);
}
function _persistWindowId() {
	_persistWindowId = _asyncToGenerator(function* (windowId) {
		cachedWindowId = windowId;
		cacheLoaded = true;
		try {
			if (windowId === null) yield chrome.storage.session.remove(SESSION_KEY);
			else yield chrome.storage.session.set({ [SESSION_KEY]: windowId });
		} catch (_unused3) {}
	});
	return _persistWindowId.apply(this, arguments);
}
try {
	var _chrome$windows;
	(_chrome$windows = chrome.windows) === null || _chrome$windows === void 0 || (_chrome$windows = _chrome$windows.onRemoved) === null || _chrome$windows === void 0 || _chrome$windows.addListener((windowId) => {
		_asyncToGenerator(function* () {
			try {
				if ((yield loadCache()) === windowId) yield persistWindowId(null);
			} catch (_unused6) {}
		})();
	});
} catch (_unused7) {}
//#endregion
//#region utils/consent-storage.ts
init_asyncToGenerator();
var STORAGE_KEY = "sitePermissionToggles";
/**
* Default 정책 (v1.0.31+ 옵션 A):
* - 3종 모두 **true** — scalemaker 는 AI 자동화가 주 목적이라 default 위임.
* - camera / microphone 은 `chrome.contentSettings.X` 의 `<all_urls>` allow 가 Chrome
*   정책상 거부되지만, `user-consent.ts` 의 `applyOriginAllow()` 가 consent 통과 시
*   현재 active tab 의 origin 단위로 `set({primaryPattern:'https://X.com/*', setting:'allow'})`
*   를 호출해 동적으로 처리 — 한 사이트당 평생 1회 set 만 일어남 (sticky 영구 저장).
* - 사용자가 의식적으로 OFF 로 내리면 그 이후로는 AI 호출마다 consent 창이 뜸.
* - update / chrome_update 이벤트 시엔 이미 storage 에 값 있으면 보존 (사용자 OFF 가 유지됨).
*/
var DEFAULT_TOGGLES = {
	camera: true,
	microphone: true,
	geolocation: true
};
/**
* Read all toggles. Missing keys → DEFAULT_TOGGLES 값.
*/
function getToggles() {
	return _getToggles.apply(this, arguments);
}
function _getToggles() {
	_getToggles = _asyncToGenerator(function* () {
		try {
			var _stored$camera, _stored$microphone, _stored$geolocation;
			const stored = (yield chrome.storage.local.get(["sitePermissionToggles"]))["sitePermissionToggles"] || {};
			return {
				camera: (_stored$camera = stored.camera) !== null && _stored$camera !== void 0 ? _stored$camera : DEFAULT_TOGGLES.camera,
				microphone: (_stored$microphone = stored.microphone) !== null && _stored$microphone !== void 0 ? _stored$microphone : DEFAULT_TOGGLES.microphone,
				geolocation: (_stored$geolocation = stored.geolocation) !== null && _stored$geolocation !== void 0 ? _stored$geolocation : DEFAULT_TOGGLES.geolocation
			};
		} catch (_unused) {
			return _objectSpread2({}, DEFAULT_TOGGLES);
		}
	});
	return _getToggles.apply(this, arguments);
}
function setToggle(_x2, _x3) {
	return _setToggle.apply(this, arguments);
}
function _setToggle() {
	_setToggle = _asyncToGenerator(function* (action, value) {
		const current = yield getToggles();
		current[action] = value;
		yield chrome.storage.local.set({ [STORAGE_KEY]: current });
	});
	return _setToggle.apply(this, arguments);
}
//#endregion
//#region entrypoints/popup/components/ConfirmDialog.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$6 = { class: "dialog-content" };
var _hoisted_2$6 = { class: "dialog-header" };
var _hoisted_3$6 = { class: "dialog-icon" };
var _hoisted_4$6 = { class: "dialog-title" };
var _hoisted_5$5 = { class: "dialog-body" };
var _hoisted_6$5 = { class: "dialog-message" };
var _hoisted_7$5 = {
	key: 0,
	class: "dialog-list"
};
var _hoisted_8$5 = {
	key: 1,
	class: "dialog-warning"
};
var _hoisted_9$5 = { class: "dialog-actions" };
var _hoisted_10$5 = ["disabled"];
//#endregion
//#region entrypoints/popup/components/ConfirmDialog.vue
var ConfirmDialog_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "ConfirmDialog",
	props: {
		visible: { type: Boolean },
		title: {},
		message: {},
		items: {},
		warning: {},
		icon: { default: "⚠️" },
		confirmText: { default: getMessage("confirmButton") },
		cancelText: { default: getMessage("cancelButton") },
		confirmingText: { default: getMessage("processingStatus") },
		isConfirming: {
			type: Boolean,
			default: false
		}
	},
	emits: ["confirm", "cancel"],
	setup(__props) {
		return (_ctx, _cache) => {
			return __props.visible ? (openBlock(), createElementBlock("div", {
				key: 0,
				class: "confirmation-dialog",
				onClick: _cache[2] || (_cache[2] = withModifiers(($event) => _ctx.$emit("cancel"), ["self"]))
			}, [createBaseVNode("div", _hoisted_1$6, [
				createBaseVNode("div", _hoisted_2$6, [createBaseVNode("span", _hoisted_3$6, toDisplayString(__props.icon), 1), createBaseVNode("h3", _hoisted_4$6, toDisplayString(__props.title), 1)]),
				createBaseVNode("div", _hoisted_5$5, [
					createBaseVNode("p", _hoisted_6$5, toDisplayString(__props.message), 1),
					__props.items && __props.items.length > 0 ? (openBlock(), createElementBlock("ul", _hoisted_7$5, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.items, (item) => {
						return openBlock(), createElementBlock("li", { key: item }, toDisplayString(item), 1);
					}), 128))])) : createCommentVNode("", true),
					__props.warning ? (openBlock(), createElementBlock("div", _hoisted_8$5, [createBaseVNode("strong", null, toDisplayString(__props.warning), 1)])) : createCommentVNode("", true)
				]),
				createBaseVNode("div", _hoisted_9$5, [createBaseVNode("button", {
					class: "dialog-button cancel-button",
					onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("cancel"))
				}, toDisplayString(__props.cancelText), 1), createBaseVNode("button", {
					class: "dialog-button confirm-button",
					disabled: __props.isConfirming,
					onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("confirm"))
				}, toDisplayString(__props.isConfirming ? __props.confirmingText : __props.confirmText), 9, _hoisted_10$5)])
			])])) : createCommentVNode("", true);
		};
	}
}), [["__scopeId", "data-v-ec7ccd99"]]);
//#endregion
//#region entrypoints/popup/components/ProgressIndicator.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$5 = {
	key: 0,
	class: "progress-section"
};
var _hoisted_2$5 = { class: "progress-indicator" };
var _hoisted_3$5 = {
	key: 0,
	class: "spinner"
};
var _hoisted_4$5 = { class: "progress-text" };
//#endregion
//#region entrypoints/popup/components/ProgressIndicator.vue
var ProgressIndicator_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "ProgressIndicator",
	props: {
		visible: {
			type: Boolean,
			default: true
		},
		text: {},
		showSpinner: {
			type: Boolean,
			default: true
		}
	},
	setup(__props) {
		return (_ctx, _cache) => {
			return __props.visible ? (openBlock(), createElementBlock("div", _hoisted_1$5, [createBaseVNode("div", _hoisted_2$5, [__props.showSpinner ? (openBlock(), createElementBlock("div", _hoisted_3$5)) : createCommentVNode("", true), createBaseVNode("span", _hoisted_4$5, toDisplayString(__props.text), 1)])])) : createCommentVNode("", true);
		};
	}
}), [["__scopeId", "data-v-64b16095"]]);
//#endregion
//#region entrypoints/popup/components/icons/DocumentIcon.vue
var DocumentIcon_default = /* @__PURE__ */ defineComponent({
	__name: "DocumentIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "2",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "M19.5 14.25v-2.625a3.375 3.375 0 0 0-3.375-3.375h-1.5A1.125 1.125 0 0 1 13.5 7.125v-1.5a3.375 3.375 0 0 0-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 0 0-9-9Z"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/icons/DatabaseIcon.vue
var DatabaseIcon_default = /* @__PURE__ */ defineComponent({
	__name: "DatabaseIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "2",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "M20.25 6.375c0 2.278-3.694 4.125-8.25 4.125S3.75 8.653 3.75 6.375m16.5 0c0-2.278-3.694-4.125-8.25-4.125S3.75 4.097 3.75 6.375m16.5 0v11.25c0 2.278-3.694 4.125-8.25 4.125s-8.25-1.847-8.25-4.125V6.375"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/icons/BoltIcon.vue
var BoltIcon_default = /* @__PURE__ */ defineComponent({
	__name: "BoltIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "1.5",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "m3.75 13.5 10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75Z"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/icons/TrashIcon.vue
var TrashIcon_default = /* @__PURE__ */ defineComponent({
	__name: "TrashIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "1.5",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/icons/CheckIcon.vue
var CheckIcon_default = /* @__PURE__ */ defineComponent({
	__name: "CheckIcon",
	props: { className: { default: "icon-small" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				viewBox: "0 0 20 20",
				fill: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"fill-rule": "evenodd",
				d: "M16.704 4.153a.75.75 0 0 1 .143 1.052l-8 10.5a.75.75 0 0 1-1.127.075l-4.5-4.5a.75.75 0 0 1 1.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 0 1 1.052-.143Z",
				"clip-rule": "evenodd"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/icons/TabIcon.vue
var TabIcon_default = /* @__PURE__ */ defineComponent({
	__name: "TabIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "2",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "M8.25 3v1.5M4.5 8.25H3m18 0h-1.5M4.5 12H3m18 0h-1.5m-16.5 3.75H3m18 0h-1.5M8.25 19.5V21M12 3v1.5m0 15V21m3.75-18v1.5m0 15V21m-9-1.5h10.5a2.25 2.25 0 0 0 2.25-2.25V6.75a2.25 2.25 0 0 0-2.25-2.25H6.75A2.25 2.25 0 0 0 4.5 6.75v10.5a2.25 2.25 0 0 0 2.25 2.25Z"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/icons/VectorIcon.vue
var VectorIcon_default = /* @__PURE__ */ defineComponent({
	__name: "VectorIcon",
	props: { className: { default: "icon-default" } },
	setup(__props) {
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("svg", {
				xmlns: "http://www.w3.org/2000/svg",
				fill: "none",
				viewBox: "0 0 24 24",
				"stroke-width": "2",
				stroke: "currentColor",
				class: normalizeClass(__props.className)
			}, [..._cache[0] || (_cache[0] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "M9 4.5a4.5 4.5 0 0 1 6 0M9 4.5V3a1.5 1.5 0 0 1 1.5-1.5h3A1.5 1.5 0 0 1 15 3v1.5M9 4.5a4.5 4.5 0 0 0-4.5 4.5v7.5A1.5 1.5 0 0 0 6 18h12a1.5 1.5 0 0 0 1.5-1.5V9a4.5 4.5 0 0 0-4.5-4.5M12 12l2.25 2.25M12 12l-2.25-2.25M12 12v6"
			}, null, -1)])], 2);
		};
	}
});
//#endregion
//#region entrypoints/popup/components/ModelCacheManagement.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$4 = { class: "model-cache-section" };
var _hoisted_2$4 = { class: "section-title" };
var _hoisted_3$4 = { class: "stats-grid" };
var _hoisted_4$4 = { class: "stats-card" };
var _hoisted_5$4 = { class: "stats-header" };
var _hoisted_6$4 = { class: "stats-label" };
var _hoisted_7$4 = { class: "stats-icon orange" };
var _hoisted_8$4 = { class: "stats-value" };
var _hoisted_9$4 = { class: "stats-card" };
var _hoisted_10$4 = { class: "stats-header" };
var _hoisted_11$4 = { class: "stats-label" };
var _hoisted_12$4 = { class: "stats-icon purple" };
var _hoisted_13$4 = { class: "stats-value" };
var _hoisted_14$4 = {
	key: 0,
	class: "cache-details"
};
var _hoisted_15$3 = { class: "cache-details-title" };
var _hoisted_16$3 = { class: "cache-entries" };
var _hoisted_17$3 = { class: "entry-info" };
var _hoisted_18$3 = { class: "entry-url" };
var _hoisted_19$3 = { class: "entry-details" };
var _hoisted_20$3 = { class: "entry-size" };
var _hoisted_21$3 = { class: "entry-age" };
var _hoisted_22$3 = {
	key: 0,
	class: "entry-expired"
};
var _hoisted_23$3 = {
	key: 1,
	class: "no-cache"
};
var _hoisted_24$3 = {
	key: 2,
	class: "loading-cache"
};
var _hoisted_25$3 = { class: "cache-actions" };
var _hoisted_26$3 = ["disabled"];
var _hoisted_27$3 = { class: "stats-icon" };
var _hoisted_28$3 = ["disabled"];
var _hoisted_29$3 = { class: "stats-icon" };
//#endregion
//#region entrypoints/popup/components/ModelCacheManagement.vue
var ModelCacheManagement_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "ModelCacheManagement",
	props: {
		cacheStats: {},
		isManagingCache: { type: Boolean }
	},
	emits: ["cleanup-cache", "clear-all-cache"],
	setup(__props) {
		const getModelNameFromUrl = (url) => {
			const match = url.match(/huggingface\.co\/([^/]+\/[^/]+)/);
			if (match) return match[1];
			return url.split("/").pop() || url;
		};
		return (_ctx, _cache) => {
			var _props$cacheStats, _props$cacheStats2;
			return openBlock(), createElementBlock("div", _hoisted_1$4, [
				createBaseVNode("h2", _hoisted_2$4, toDisplayString(unref(getMessage)("modelCacheManagementLabel")), 1),
				createBaseVNode("div", _hoisted_3$4, [createBaseVNode("div", _hoisted_4$4, [createBaseVNode("div", _hoisted_5$4, [createBaseVNode("p", _hoisted_6$4, toDisplayString(unref(getMessage)("cacheSizeLabel")), 1), createBaseVNode("span", _hoisted_7$4, [createVNode(unref(DatabaseIcon_default))])]), createBaseVNode("p", _hoisted_8$4, toDisplayString(((_props$cacheStats = __props.cacheStats) === null || _props$cacheStats === void 0 ? void 0 : _props$cacheStats.totalSizeMB) || 0) + " MB", 1)]), createBaseVNode("div", _hoisted_9$4, [createBaseVNode("div", _hoisted_10$4, [createBaseVNode("p", _hoisted_11$4, toDisplayString(unref(getMessage)("cacheEntriesLabel")), 1), createBaseVNode("span", _hoisted_12$4, [createVNode(unref(VectorIcon_default))])]), createBaseVNode("p", _hoisted_13$4, toDisplayString(((_props$cacheStats2 = __props.cacheStats) === null || _props$cacheStats2 === void 0 ? void 0 : _props$cacheStats2.entryCount) || 0), 1)])]),
				__props.cacheStats && __props.cacheStats.entries.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_14$4, [createBaseVNode("h3", _hoisted_15$3, toDisplayString(unref(getMessage)("cacheDetailsLabel")), 1), createBaseVNode("div", _hoisted_16$3, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.cacheStats.entries, (entry) => {
					return openBlock(), createElementBlock("div", {
						key: entry.url,
						class: "cache-entry"
					}, [createBaseVNode("div", _hoisted_17$3, [createBaseVNode("div", _hoisted_18$3, toDisplayString(getModelNameFromUrl(entry.url)), 1), createBaseVNode("div", _hoisted_19$3, [
						createBaseVNode("span", _hoisted_20$3, toDisplayString(entry.sizeMB) + " MB", 1),
						createBaseVNode("span", _hoisted_21$3, toDisplayString(entry.age), 1),
						entry.expired ? (openBlock(), createElementBlock("span", _hoisted_22$3, toDisplayString(unref(getMessage)("expiredLabel")), 1)) : createCommentVNode("", true)
					])])]);
				}), 128))])])) : __props.cacheStats && __props.cacheStats.entries.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_23$3, [createBaseVNode("p", null, toDisplayString(unref(getMessage)("noCacheDataMessage")), 1)])) : !__props.cacheStats ? (openBlock(), createElementBlock("div", _hoisted_24$3, [createBaseVNode("p", null, toDisplayString(unref(getMessage)("loadingCacheInfoStatus")), 1)])) : createCommentVNode("", true),
				__props.isManagingCache ? (openBlock(), createBlock(ProgressIndicator_default, {
					key: 3,
					visible: __props.isManagingCache,
					text: __props.isManagingCache ? unref(getMessage)("processingCacheStatus") : "",
					showSpinner: true
				}, null, 8, ["visible", "text"])) : createCommentVNode("", true),
				createBaseVNode("div", _hoisted_25$3, [createBaseVNode("div", {
					class: "secondary-button",
					disabled: __props.isManagingCache,
					onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("cleanup-cache"))
				}, [createBaseVNode("span", _hoisted_27$3, [createVNode(unref(DatabaseIcon_default))]), createBaseVNode("span", null, toDisplayString(__props.isManagingCache ? unref(getMessage)("cleaningStatus") : unref(getMessage)("cleanExpiredCacheButton")), 1)], 8, _hoisted_26$3), createBaseVNode("div", {
					class: "danger-button",
					disabled: __props.isManagingCache,
					onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("clear-all-cache"))
				}, [createBaseVNode("span", _hoisted_29$3, [createVNode(unref(TrashIcon_default))]), createBaseVNode("span", null, toDisplayString(__props.isManagingCache ? unref(getMessage)("clearingStatus") : unref(getMessage)("clearAllCacheButton")), 1)], 8, _hoisted_28$3)])
			]);
		};
	}
}), [["__scopeId", "data-v-7ccb152f"]]);
//#endregion
//#region entrypoints/popup/components/LocalModelPage.vue?vue&type=script&setup=true&lang.ts
var _hoisted_1$3 = { class: "local-model-page" };
var _hoisted_2$3 = { class: "page-header" };
var _hoisted_3$3 = { class: "page-content" };
var _hoisted_4$3 = { class: "section" };
var _hoisted_5$3 = { class: "section-title" };
var _hoisted_6$3 = { class: "semantic-engine-card" };
var _hoisted_7$3 = { class: "semantic-engine-status" };
var _hoisted_8$3 = { class: "status-info" };
var _hoisted_9$3 = { class: "status-text" };
var _hoisted_10$3 = {
	key: 0,
	class: "status-timestamp"
};
var _hoisted_11$3 = ["disabled"];
var _hoisted_12$3 = { class: "section" };
var _hoisted_13$3 = { class: "section-title" };
var _hoisted_14$3 = {
	key: 1,
	class: "error-card"
};
var _hoisted_15$2 = { class: "error-content" };
var _hoisted_16$2 = { class: "error-details" };
var _hoisted_17$2 = { class: "error-title" };
var _hoisted_18$2 = { class: "error-message" };
var _hoisted_19$2 = { class: "error-suggestion" };
var _hoisted_20$2 = ["disabled"];
var _hoisted_21$2 = { class: "model-list" };
var _hoisted_22$2 = ["onClick"];
var _hoisted_23$2 = { class: "model-header" };
var _hoisted_24$2 = { class: "model-info" };
var _hoisted_25$2 = { class: "model-description" };
var _hoisted_26$2 = {
	key: 0,
	class: "check-icon"
};
var _hoisted_27$2 = { class: "model-tags" };
var _hoisted_28$2 = { class: "model-tag performance" };
var _hoisted_29$2 = { class: "model-tag size" };
var _hoisted_30$2 = { class: "model-tag dimension" };
var _hoisted_31$2 = { class: "section" };
var _hoisted_32$2 = { class: "section-title" };
var _hoisted_33$1 = { class: "stats-grid" };
var _hoisted_34$1 = { class: "stats-card" };
var _hoisted_35$1 = { class: "stats-header" };
var _hoisted_36$1 = { class: "stats-label" };
var _hoisted_37$1 = { class: "stats-icon violet" };
var _hoisted_38 = { class: "stats-value" };
var _hoisted_39 = { class: "stats-card" };
var _hoisted_40 = { class: "stats-header" };
var _hoisted_41 = { class: "stats-label" };
var _hoisted_42 = { class: "stats-icon teal" };
var _hoisted_43 = { class: "stats-value" };
var _hoisted_44 = { class: "stats-card" };
var _hoisted_45 = { class: "stats-header" };
var _hoisted_46 = { class: "stats-label" };
var _hoisted_47 = { class: "stats-icon blue" };
var _hoisted_48 = { class: "stats-value" };
var _hoisted_49 = { class: "stats-card" };
var _hoisted_50 = { class: "stats-header" };
var _hoisted_51 = { class: "stats-label" };
var _hoisted_52 = { class: "stats-icon green" };
var _hoisted_53 = { class: "stats-value" };
var _hoisted_54 = ["disabled"];
//#endregion
//#region entrypoints/popup/components/LocalModelPage.vue
var LocalModelPage_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "LocalModelPage",
	props: {
		semanticEngineStatus: {},
		isSemanticEngineInitializing: { type: Boolean },
		semanticEngineInitProgress: {},
		semanticEngineLastUpdated: {},
		availableModels: {},
		currentModel: {},
		isModelSwitching: { type: Boolean },
		isModelDownloading: { type: Boolean },
		modelDownloadProgress: {},
		modelInitializationStatus: {},
		modelErrorMessage: {},
		modelErrorType: {},
		storageStats: {},
		isClearingData: { type: Boolean },
		clearDataProgress: {},
		cacheStats: {},
		isManagingCache: { type: Boolean }
	},
	emits: [
		"back",
		"initializeSemanticEngine",
		"switchModel",
		"retryModelInitialization",
		"showClearConfirmation",
		"cleanupCache",
		"clearAllCache"
	],
	setup(__props) {
		const props = __props;
		const getSemanticEngineStatusClass = () => {
			switch (props.semanticEngineStatus) {
				case "ready": return "bg-emerald-500";
				case "initializing": return "bg-yellow-500";
				case "error": return "bg-red-500";
				default: return "bg-gray-500";
			}
		};
		const getSemanticEngineStatusText = () => {
			switch (props.semanticEngineStatus) {
				case "ready": return getMessage("semanticEngineReadyStatus");
				case "initializing": return getMessage("semanticEngineInitializingStatus");
				case "error": return getMessage("semanticEngineInitFailedStatus");
				default: return getMessage("semanticEngineNotInitStatus");
			}
		};
		const getSemanticEngineButtonText = () => {
			switch (props.semanticEngineStatus) {
				case "ready": return getMessage("reinitializeButton");
				case "initializing": return getMessage("initializingStatus");
				case "error": return getMessage("reinitializeButton");
				default: return getMessage("initSemanticEngineButton");
			}
		};
		const progressText = computed(() => {
			if (props.isModelDownloading) return getMessage("downloadingModelStatus", [props.modelDownloadProgress.toString()]);
			else if (props.isModelSwitching) return getMessage("switchingModelStatus");
			return "";
		});
		const errorTypeText = computed(() => {
			switch (props.modelErrorType) {
				case "network": return getMessage("networkErrorMessage");
				case "file": return getMessage("modelCorruptedErrorMessage");
				default: return getMessage("unknownErrorMessage");
			}
		});
		const getModelDescription = (model) => {
			switch (model.preset) {
				case "multilingual-e5-small": return getMessage("lightweightModelDescription");
				case "multilingual-e5-base": return getMessage("betterThanSmallDescription");
				default: return getMessage("multilingualModelDescription");
			}
		};
		const getPerformanceText = (performance) => {
			switch (performance) {
				case "fast": return getMessage("fastPerformance");
				case "balanced": return getMessage("balancedPerformance");
				case "accurate": return getMessage("accuratePerformance");
				default: return performance;
			}
		};
		const formatIndexSize = () => {
			var _props$storageStats;
			if (!((_props$storageStats = props.storageStats) === null || _props$storageStats === void 0 ? void 0 : _props$storageStats.indexSize)) return "0 MB";
			return `${Math.round(props.storageStats.indexSize / (1024 * 1024))} MB`;
		};
		return (_ctx, _cache) => {
			var _props$storageStats2, _props$storageStats3, _props$storageStats4;
			return openBlock(), createElementBlock("div", _hoisted_1$3, [createBaseVNode("div", _hoisted_2$3, [createBaseVNode("button", {
				class: "back-button",
				onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("back")),
				title: "返回首页"
			}, [..._cache[6] || (_cache[6] = [createBaseVNode("svg", {
				viewBox: "0 0 24 24",
				width: "20",
				height: "20",
				fill: "none",
				stroke: "currentColor",
				"stroke-width": "2"
			}, [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				d: "M15 19l-7-7 7-7"
			})], -1), createBaseVNode("span", null, "返回", -1)])]), _cache[7] || (_cache[7] = createBaseVNode("h2", { class: "page-title" }, "本地模型", -1))]), createBaseVNode("div", _hoisted_3$3, [
				createBaseVNode("div", _hoisted_4$3, [createBaseVNode("h3", _hoisted_5$3, toDisplayString(unref(getMessage)("semanticEngineLabel")), 1), createBaseVNode("div", _hoisted_6$3, [
					createBaseVNode("div", _hoisted_7$3, [createBaseVNode("div", _hoisted_8$3, [createBaseVNode("span", { class: normalizeClass(["status-dot", getSemanticEngineStatusClass()]) }, null, 2), createBaseVNode("span", _hoisted_9$3, toDisplayString(getSemanticEngineStatusText()), 1)]), __props.semanticEngineLastUpdated ? (openBlock(), createElementBlock("div", _hoisted_10$3, toDisplayString(unref(getMessage)("lastUpdatedLabel")) + " " + toDisplayString(new Date(__props.semanticEngineLastUpdated).toLocaleTimeString()), 1)) : createCommentVNode("", true)]),
					__props.isSemanticEngineInitializing ? (openBlock(), createBlock(ProgressIndicator_default, {
						key: 0,
						visible: __props.isSemanticEngineInitializing,
						text: __props.semanticEngineInitProgress,
						showSpinner: true
					}, null, 8, ["visible", "text"])) : createCommentVNode("", true),
					createBaseVNode("button", {
						class: "primary-action-button",
						disabled: __props.isSemanticEngineInitializing,
						onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("initializeSemanticEngine"))
					}, [createVNode(unref(BoltIcon_default)), createBaseVNode("span", null, toDisplayString(getSemanticEngineButtonText()), 1)], 8, _hoisted_11$3)
				])]),
				createBaseVNode("div", _hoisted_12$3, [
					createBaseVNode("h3", _hoisted_13$3, toDisplayString(unref(getMessage)("embeddingModelLabel")), 1),
					__props.isModelSwitching || __props.isModelDownloading ? (openBlock(), createBlock(ProgressIndicator_default, {
						key: 0,
						visible: __props.isModelSwitching || __props.isModelDownloading,
						text: progressText.value,
						showSpinner: true
					}, null, 8, ["visible", "text"])) : createCommentVNode("", true),
					__props.modelInitializationStatus === "error" ? (openBlock(), createElementBlock("div", _hoisted_14$3, [createBaseVNode("div", _hoisted_15$2, [_cache[8] || (_cache[8] = createBaseVNode("div", { class: "error-icon" }, "⚠️", -1)), createBaseVNode("div", _hoisted_16$2, [
						createBaseVNode("p", _hoisted_17$2, toDisplayString(unref(getMessage)("semanticEngineInitFailedStatus")), 1),
						createBaseVNode("p", _hoisted_18$2, toDisplayString(__props.modelErrorMessage || unref(getMessage)("semanticEngineInitFailedStatus")), 1),
						createBaseVNode("p", _hoisted_19$2, toDisplayString(errorTypeText.value), 1)
					])]), createBaseVNode("button", {
						class: "retry-button",
						onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("retryModelInitialization")),
						disabled: __props.isModelSwitching || __props.isModelDownloading
					}, [_cache[9] || (_cache[9] = createBaseVNode("span", null, "🔄", -1)), createBaseVNode("span", null, toDisplayString(unref(getMessage)("retryButton")), 1)], 8, _hoisted_20$2)])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_21$2, [(openBlock(true), createElementBlock(Fragment, null, renderList(__props.availableModels, (model) => {
						return openBlock(), createElementBlock("div", {
							key: model.preset,
							class: normalizeClass(["model-card", {
								selected: __props.currentModel === model.preset,
								disabled: __props.isModelSwitching || __props.isModelDownloading
							}]),
							onClick: ($event) => !__props.isModelSwitching && !__props.isModelDownloading && _ctx.$emit("switchModel", model.preset)
						}, [createBaseVNode("div", _hoisted_23$2, [createBaseVNode("div", _hoisted_24$2, [createBaseVNode("p", { class: normalizeClass(["model-name", { "selected-text": __props.currentModel === model.preset }]) }, toDisplayString(model.preset), 3), createBaseVNode("p", _hoisted_25$2, toDisplayString(getModelDescription(model)), 1)]), __props.currentModel === model.preset ? (openBlock(), createElementBlock("div", _hoisted_26$2, [createVNode(unref(CheckIcon_default), { class: "text-white" })])) : createCommentVNode("", true)]), createBaseVNode("div", _hoisted_27$2, [
							createBaseVNode("span", _hoisted_28$2, toDisplayString(getPerformanceText(model.performance)), 1),
							createBaseVNode("span", _hoisted_29$2, toDisplayString(model.size), 1),
							createBaseVNode("span", _hoisted_30$2, toDisplayString(model.dimension) + "D", 1)
						])], 10, _hoisted_22$2);
					}), 128))])
				]),
				createBaseVNode("div", _hoisted_31$2, [
					createBaseVNode("h3", _hoisted_32$2, toDisplayString(unref(getMessage)("indexDataManagementLabel")), 1),
					createBaseVNode("div", _hoisted_33$1, [
						createBaseVNode("div", _hoisted_34$1, [createBaseVNode("div", _hoisted_35$1, [createBaseVNode("p", _hoisted_36$1, toDisplayString(unref(getMessage)("indexedPagesLabel")), 1), createBaseVNode("span", _hoisted_37$1, [createVNode(unref(DocumentIcon_default))])]), createBaseVNode("p", _hoisted_38, toDisplayString(((_props$storageStats2 = __props.storageStats) === null || _props$storageStats2 === void 0 ? void 0 : _props$storageStats2.indexedPages) || 0), 1)]),
						createBaseVNode("div", _hoisted_39, [createBaseVNode("div", _hoisted_40, [createBaseVNode("p", _hoisted_41, toDisplayString(unref(getMessage)("indexSizeLabel")), 1), createBaseVNode("span", _hoisted_42, [createVNode(unref(DatabaseIcon_default))])]), createBaseVNode("p", _hoisted_43, toDisplayString(formatIndexSize()), 1)]),
						createBaseVNode("div", _hoisted_44, [createBaseVNode("div", _hoisted_45, [createBaseVNode("p", _hoisted_46, toDisplayString(unref(getMessage)("activeTabsLabel")), 1), createBaseVNode("span", _hoisted_47, [createVNode(unref(TabIcon_default))])]), createBaseVNode("p", _hoisted_48, toDisplayString(((_props$storageStats3 = __props.storageStats) === null || _props$storageStats3 === void 0 ? void 0 : _props$storageStats3.totalTabs) || 0), 1)]),
						createBaseVNode("div", _hoisted_49, [createBaseVNode("div", _hoisted_50, [createBaseVNode("p", _hoisted_51, toDisplayString(unref(getMessage)("vectorDocumentsLabel")), 1), createBaseVNode("span", _hoisted_52, [createVNode(unref(VectorIcon_default))])]), createBaseVNode("p", _hoisted_53, toDisplayString(((_props$storageStats4 = __props.storageStats) === null || _props$storageStats4 === void 0 ? void 0 : _props$storageStats4.totalDocuments) || 0), 1)])
					]),
					__props.isClearingData && __props.clearDataProgress ? (openBlock(), createBlock(ProgressIndicator_default, {
						key: 0,
						visible: __props.isClearingData,
						text: __props.clearDataProgress,
						showSpinner: true
					}, null, 8, ["visible", "text"])) : createCommentVNode("", true),
					createBaseVNode("button", {
						class: "danger-action-button",
						disabled: __props.isClearingData,
						onClick: _cache[3] || (_cache[3] = ($event) => _ctx.$emit("showClearConfirmation"))
					}, [createVNode(unref(TrashIcon_default)), createBaseVNode("span", null, toDisplayString(__props.isClearingData ? unref(getMessage)("clearingStatus") : unref(getMessage)("clearAllDataButton")), 1)], 8, _hoisted_54)
				]),
				createVNode(ModelCacheManagement_default, {
					"cache-stats": __props.cacheStats,
					"is-managing-cache": __props.isManagingCache,
					onCleanupCache: _cache[4] || (_cache[4] = ($event) => _ctx.$emit("cleanupCache")),
					onClearAllCache: _cache[5] || (_cache[5] = ($event) => _ctx.$emit("clearAllCache"))
				}, null, 8, ["cache-stats", "is-managing-cache"])
			])]);
		};
	}
}), [["__scopeId", "data-v-2f30c5e2"]]);
//#endregion
//#region utils/force-reconnect.ts
init_asyncToGenerator();
var DEFAULT_TIMEOUTS = {
	process_kill: 5e3,
	port_free: 5e3,
	spawn: 3e4,
	handshake: 1e4,
	connect: 8e3,
	mcp_ping: 5e3
};
/**
* Sleep helper.
*/
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
/**
* fetch 가 throw 하면 false (서버 죽음), 200 이면 true.
*/
var probeHealth = function() {
	var _ref = _asyncToGenerator(function* (url, controllerTimeoutMs = 1500) {
		const controller = new AbortController();
		const timeoutId = setTimeout(() => controller.abort(), controllerTimeoutMs);
		try {
			var _payload$bridge;
			const res = yield fetch(url, {
				method: "GET",
				signal: controller.signal
			});
			if (!res.ok) return { alive: false };
			const payload = yield res.json().catch(() => void 0);
			return {
				alive: true,
				pid: payload === null || payload === void 0 || (_payload$bridge = payload.bridge) === null || _payload$bridge === void 0 ? void 0 : _payload$bridge.pid,
				payload
			};
		} catch (_unused) {
			return { alive: false };
		} finally {
			clearTimeout(timeoutId);
		}
	});
	return function probeHealth(_x) {
		return _ref.apply(this, arguments);
	};
}();
var now = () => Date.now();
var emit = (cb, step, patch) => {
	const result = _objectSpread2({ step }, patch);
	cb === null || cb === void 0 || cb(result);
	return result;
};
/**
* Main entrypoint.
*/
function forceReconnect() {
	return _forceReconnect.apply(this, arguments);
}
function _forceReconnect() {
	_forceReconnect = _asyncToGenerator(function* (opts = {}) {
		var _opts$port, _opts$host, _opts$timeouts;
		const port = (_opts$port = opts.port) !== null && _opts$port !== void 0 ? _opts$port : 12320;
		const host = (_opts$host = opts.host) !== null && _opts$host !== void 0 ? _opts$host : "127.0.0.1";
		const timeouts = _objectSpread2(_objectSpread2({}, DEFAULT_TIMEOUTS), (_opts$timeouts = opts.timeouts) !== null && _opts$timeouts !== void 0 ? _opts$timeouts : {});
		const base = `http://${host}:${port}`;
		const stages = [];
		const cb = opts.onProgress;
		{
			const step = "process_kill";
			const t0 = now();
			emit(cb, step, {
				status: "running",
				message: "POST /admin/drain + /admin/kill-self"
			});
			const tryEndpoint = function() {
				var _ref2 = _asyncToGenerator(function* (path) {
					try {
						const res = yield fetch(`${base}${path}`, {
							method: "POST",
							signal: AbortSignal.timeout(2e3)
						});
						return {
							ok: res.ok,
							note: `${path}=${res.status}`
						};
					} catch (e) {
						return {
							ok: false,
							note: `${path}=err:${(e === null || e === void 0 ? void 0 : e.name) || "unknown"}`
						};
					}
				});
				return function tryEndpoint(_x2) {
					return _ref2.apply(this, arguments);
				};
			}();
			const [drainRes, killRes] = yield Promise.all([tryEndpoint("/admin/drain"), tryEndpoint("/admin/kill-self")]);
			const duration = now() - t0;
			const anyOk = drainRes.ok || killRes.ok;
			const allFailed = !drainRes.ok && !killRes.ok;
			if (anyOk) {
				const r = emit(cb, step, {
					status: "success",
					message: `kill request accepted (${drainRes.note}, ${killRes.note})`,
					durationMs: duration
				});
				stages.push(r);
			} else if (allFailed) {
				const r = emit(cb, step, {
					status: "skipped",
					message: `bridge unreachable (${drainRes.note}, ${killRes.note}) — verifying via /health`,
					durationMs: duration
				});
				stages.push(r);
			}
		}
		{
			const step = "port_free";
			const t0 = now();
			emit(cb, step, {
				status: "running",
				message: "waiting for /health to fail"
			});
			const deadline = t0 + timeouts[step];
			let confirmedDead = false;
			while (now() < deadline) {
				if (!(yield probeHealth(`${base}/health`, 800)).alive) {
					confirmedDead = true;
					break;
				}
				yield sleep(300);
			}
			const duration = now() - t0;
			if (confirmedDead) {
				const r = emit(cb, step, {
					status: "success",
					message: "bridge process down (port freed)",
					durationMs: duration
				});
				stages.push(r);
			} else {
				const r = emit(cb, step, {
					status: "fail",
					message: `bridge still answering /health after ${timeouts[step]}ms`,
					durationMs: duration
				});
				stages.push(r);
				return {
					ok: false,
					stages,
					failedAt: step
				};
			}
		}
		{
			const step = "spawn";
			const t0 = now();
			emit(cb, step, {
				status: "running",
				message: "asking background to reconnect native"
			});
			try {
				const respawnOk = yield chrome.runtime.sendMessage({ type: "force-reconnect-respawn" });
				const duration = now() - t0;
				if (respawnOk && respawnOk.ok) {
					const r = emit(cb, step, {
						status: "success",
						message: "background respawn message acknowledged",
						durationMs: duration
					});
					stages.push(r);
				} else {
					const r = emit(cb, step, {
						status: "fail",
						message: `background respawn declined: ${JSON.stringify(respawnOk)}`,
						durationMs: duration
					});
					stages.push(r);
					return {
						ok: false,
						stages,
						failedAt: step
					};
				}
			} catch (e) {
				const duration = now() - t0;
				const r = emit(cb, step, {
					status: "skipped",
					message: `background sendMessage failed: ${(e === null || e === void 0 ? void 0 : e.message) || e} (will probe directly)`,
					durationMs: duration
				});
				stages.push(r);
			}
		}
		let finalBridgePid;
		{
			const step = "handshake";
			const t0 = now();
			emit(cb, step, {
				status: "running",
				message: "waiting for /health to return 200"
			});
			const deadline = t0 + timeouts[step];
			let alive = false;
			while (now() < deadline) {
				const probe = yield probeHealth(`${base}/health`, 1500);
				if (probe.alive) {
					alive = true;
					finalBridgePid = probe.pid;
					break;
				}
				yield sleep(500);
			}
			const duration = now() - t0;
			if (alive) {
				const r = emit(cb, step, {
					status: "success",
					message: `new bridge alive${finalBridgePid ? ` (pid ${finalBridgePid})` : ""}`,
					durationMs: duration
				});
				stages.push(r);
			} else {
				const r = emit(cb, step, {
					status: "fail",
					message: `bridge did not respond within ${timeouts[step]}ms — try connect step`,
					durationMs: duration
				});
				stages.push(r);
			}
		}
		{
			const step = "connect";
			const t0 = now();
			emit(cb, step, {
				status: "running",
				message: "sending connectNative (= ⚡ 연결 버튼 효과)"
			});
			try {
				const res = yield chrome.runtime.sendMessage({
					type: "connectNative",
					port
				});
				const ackOk = !!(res && res.success);
				const connectedFlag = !!(res && (res.connected === true || res.connected === void 0));
				if (!ackOk) {
					const r = emit(cb, step, {
						status: "fail",
						message: `connectNative declined: ${JSON.stringify(res)}`,
						durationMs: now() - t0
					});
					stages.push(r);
					return {
						ok: false,
						stages,
						failedAt: step,
						finalBridgePid
					};
				}
				const probeDeadline = t0 + timeouts[step];
				let healthOk = false;
				while (now() < probeDeadline) {
					const probe = yield probeHealth(`${base}/health`, 1e3);
					if (probe.alive) {
						var _probe$pid;
						healthOk = true;
						finalBridgePid = (_probe$pid = probe.pid) !== null && _probe$pid !== void 0 ? _probe$pid : finalBridgePid;
						break;
					}
					yield sleep(400);
				}
				const duration = now() - t0;
				if (healthOk) {
					const r = emit(cb, step, {
						status: "success",
						message: `connectNative ack + /health 200${finalBridgePid ? ` (pid ${finalBridgePid})` : ""}`,
						durationMs: duration
					});
					stages.push(r);
				} else {
					const r = emit(cb, step, {
						status: "fail",
						message: `connectNative ack 했지만 /health 응답 없음 (connected=${connectedFlag})`,
						durationMs: duration
					});
					stages.push(r);
					return {
						ok: false,
						stages,
						failedAt: step,
						finalBridgePid
					};
				}
			} catch (e) {
				const r = emit(cb, step, {
					status: "fail",
					message: `connectNative threw: ${(e === null || e === void 0 ? void 0 : e.message) || e}`,
					durationMs: now() - t0
				});
				stages.push(r);
				return {
					ok: false,
					stages,
					failedAt: step,
					finalBridgePid
				};
			}
		}
		let finalSessionId;
		{
			const step = "mcp_ping";
			const t0 = now();
			emit(cb, step, {
				status: "running",
				message: "POST /mcp initialize"
			});
			try {
				var _res$headers$get;
				const res = yield fetch(`${base}/mcp`, {
					method: "POST",
					headers: {
						"Content-Type": "application/json",
						Accept: "application/json, text/event-stream"
					},
					body: JSON.stringify({
						jsonrpc: "2.0",
						id: `force-reconnect-${Date.now()}`,
						method: "initialize",
						params: {
							protocolVersion: "2024-11-05",
							capabilities: {},
							clientInfo: {
								name: "mcp-chrome-scalemaker-supervisor",
								version: "1.0.0"
							}
						}
					}),
					signal: AbortSignal.timeout(timeouts[step])
				});
				const duration = now() - t0;
				finalSessionId = (_res$headers$get = res.headers.get("mcp-session-id")) !== null && _res$headers$get !== void 0 ? _res$headers$get : void 0;
				if (res.ok && finalSessionId) {
					const r = emit(cb, step, {
						status: "success",
						message: `MCP initialize ok (session ${finalSessionId.slice(0, 8)}…)`,
						durationMs: duration
					});
					stages.push(r);
				} else {
					const r = emit(cb, step, {
						status: "fail",
						message: `MCP initialize failed (HTTP ${res.status}, sid=${finalSessionId})`,
						durationMs: duration
					});
					stages.push(r);
					return {
						ok: false,
						stages,
						failedAt: step,
						finalBridgePid,
						finalSessionId
					};
				}
			} catch (e) {
				const duration = now() - t0;
				const r = emit(cb, step, {
					status: "fail",
					message: `MCP initialize threw: ${(e === null || e === void 0 ? void 0 : e.message) || e}`,
					durationMs: duration
				});
				stages.push(r);
				return {
					ok: false,
					stages,
					failedAt: step,
					finalBridgePid
				};
			}
		}
		return {
			ok: true,
			stages,
			finalBridgePid,
			finalSessionId
		};
	});
	return _forceReconnect.apply(this, arguments);
}
//#endregion
//#region entrypoints/popup/components/ForceReconnect.vue?vue&type=script&setup=true&lang.ts
init_asyncToGenerator();
var _hoisted_1$2 = { class: "force-reconnect-card" };
var _hoisted_2$2 = { class: "fr-title" };
var _hoisted_3$2 = { class: "fr-port-hint" };
var _hoisted_4$2 = { class: "fr-summary" };
var _hoisted_5$2 = { key: 0 };
var _hoisted_6$2 = ["disabled"];
var _hoisted_7$2 = { key: 0 };
var _hoisted_8$2 = { key: 1 };
var _hoisted_9$2 = { class: "fr-stages" };
var _hoisted_10$2 = { class: "fr-stage-icon" };
var _hoisted_11$2 = { class: "fr-stage-label" };
var _hoisted_12$2 = {
	key: 0,
	class: "fr-stage-time"
};
var _hoisted_13$2 = {
	key: 0,
	class: "fr-logs"
};
var _hoisted_14$2 = { class: "fr-logs-pre" };
//#endregion
//#region entrypoints/popup/components/ForceReconnect.vue
var ForceReconnect_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "ForceReconnect",
	props: { port: {} },
	emits: ["reconnected"],
	setup(__props, { emit: __emit }) {
		const props = __props;
		const emit = __emit;
		const expanded = ref(false);
		const stages = ref({
			process_kill: void 0,
			port_free: void 0,
			spawn: void 0,
			handshake: void 0,
			connect: void 0,
			mcp_ping: void 0
		});
		const logs = ref([]);
		const inFlight = ref(false);
		const lastResult = ref({});
		const stageLabel = {
			process_kill: "① 프로세스 종료",
			port_free: "② 포트 해제 확인",
			spawn: "③ 브릿지 재시작",
			handshake: "④ 네이티브 핸드셰이크",
			connect: "⑤ 연결 (⚡ 연결 버튼 효과)",
			mcp_ping: "⑥ MCP 초기화 핑"
		};
		const statusIcon = (s) => {
			if (!s) return "⚪";
			switch (s.status) {
				case "running": return "🔄";
				case "success": return "✅";
				case "fail": return "❌";
				case "skipped": return "⏭️";
				default: return "⚪";
			}
		};
		const ts = () => (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", { hour12: false });
		const append = (line) => {
			logs.value.push(`${ts()}  ${line}`);
			if (logs.value.length > 50) logs.value.shift();
		};
		const handleClick = function() {
			var _ref = _asyncToGenerator(function* () {
				if (inFlight.value) return;
				inFlight.value = true;
				lastResult.value = {};
				for (const k of Object.keys(stages.value)) stages.value[k] = void 0;
				logs.value = [];
				append(`강제 재연결 시작 (port ${props.port})`);
				const result = yield forceReconnect({
					port: props.port,
					onProgress: (s) => {
						stages.value[s.step] = s;
						const dur = s.durationMs ? ` (${s.durationMs}ms)` : "";
						append(`${stageLabel[s.step]}: ${s.status}${dur}${s.message ? " — " + s.message : ""}`);
					}
				});
				lastResult.value = {
					ok: result.ok,
					failedAt: result.failedAt,
					finalBridgePid: result.finalBridgePid,
					finalSessionId: result.finalSessionId
				};
				if (result.ok) {
					var _result$finalBridgePi, _result$finalSessionI, _result$finalSessionI2;
					append(`✅ 연결됨 (pid ${(_result$finalBridgePi = result.finalBridgePid) !== null && _result$finalBridgePi !== void 0 ? _result$finalBridgePi : "?"}, 세션 ${(_result$finalSessionI = (_result$finalSessionI2 = result.finalSessionId) === null || _result$finalSessionI2 === void 0 ? void 0 : _result$finalSessionI2.slice(0, 8)) !== null && _result$finalSessionI !== void 0 ? _result$finalSessionI : "?"}…)`);
				} else append(`❌ ${result.failedAt} 단계 실패`);
				inFlight.value = false;
				emit("reconnected", {
					ok: result.ok,
					finalBridgePid: result.finalBridgePid
				});
			});
			return function handleClick() {
				return _ref.apply(this, arguments);
			};
		}();
		const summaryText = computed(() => {
			var _lastResult$value$fin;
			if (inFlight.value) return "진행 중…";
			if (lastResult.value.ok === true) return `연결됨 (pid ${(_lastResult$value$fin = lastResult.value.finalBridgePid) !== null && _lastResult$value$fin !== void 0 ? _lastResult$value$fin : "?"})`;
			if (lastResult.value.ok === false) return `${lastResult.value.failedAt} 단계에서 실패`;
			return "대기 중 — 클릭하면 강제 재연결";
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1$2, [createBaseVNode("div", {
				class: "fr-header fr-header--toggle",
				onClick: _cache[0] || (_cache[0] = ($event) => expanded.value = !expanded.value)
			}, [createBaseVNode("h3", _hoisted_2$2, [
				createBaseVNode("span", { class: normalizeClass(["fr-chevron", { "fr-chevron--open": expanded.value || inFlight.value }]) }, "▶", 2),
				_cache[1] || (_cache[1] = createTextVNode(" ⚡ 강제 재연결 ", -1)),
				createBaseVNode("span", _hoisted_3$2, "(포트 " + toDisplayString(props.port) + ")", 1)
			]), createBaseVNode("p", _hoisted_4$2, toDisplayString(summaryText.value), 1)]), expanded.value || inFlight.value ? (openBlock(), createElementBlock("div", _hoisted_5$2, [
				createBaseVNode("button", {
					class: "fr-button",
					disabled: inFlight.value,
					onClick: withModifiers(handleClick, ["stop"])
				}, [inFlight.value ? (openBlock(), createElementBlock("span", _hoisted_7$2, "재연결 중…")) : (openBlock(), createElementBlock("span", _hoisted_8$2, "⚡ 강제 재연결"))], 8, _hoisted_6$2),
				createBaseVNode("div", _hoisted_9$2, [(openBlock(), createElementBlock(Fragment, null, renderList(stageLabel, (label, key) => {
					var _stages$value$key$sta, _stages$value$key, _stages$value$key2, _stages$value$key3;
					return createBaseVNode("div", {
						key,
						class: normalizeClass(["fr-stage", `fr-stage--${(_stages$value$key$sta = (_stages$value$key = stages.value[key]) === null || _stages$value$key === void 0 ? void 0 : _stages$value$key.status) !== null && _stages$value$key$sta !== void 0 ? _stages$value$key$sta : "idle"}`])
					}, [
						createBaseVNode("span", _hoisted_10$2, toDisplayString(statusIcon(stages.value[key])), 1),
						createBaseVNode("span", _hoisted_11$2, toDisplayString(label), 1),
						((_stages$value$key2 = stages.value[key]) === null || _stages$value$key2 === void 0 ? void 0 : _stages$value$key2.durationMs) ? (openBlock(), createElementBlock("span", _hoisted_12$2, toDisplayString((_stages$value$key3 = stages.value[key]) === null || _stages$value$key3 === void 0 ? void 0 : _stages$value$key3.durationMs) + "ms ", 1)) : createCommentVNode("", true)
					], 2);
				}), 64))]),
				logs.value.length > 0 ? (openBlock(), createElementBlock("details", _hoisted_13$2, [createBaseVNode("summary", null, "로그 (" + toDisplayString(logs.value.length) + ")", 1), createBaseVNode("pre", _hoisted_14$2, toDisplayString(logs.value.join("\n")), 1)])) : createCommentVNode("", true)
			])) : createCommentVNode("", true)]);
		};
	}
}), [["__scopeId", "data-v-a6afa230"]]);
//#endregion
//#region entrypoints/popup/components/Diagnostic.vue?vue&type=script&setup=true&lang.ts
init_asyncToGenerator();
var _hoisted_1$1 = { class: "diag-card" };
var _hoisted_2$1 = { class: "diag-title" };
var _hoisted_3$1 = ["disabled"];
var _hoisted_4$1 = { key: 0 };
var _hoisted_5$1 = { class: "diag-section" };
var _hoisted_6$1 = { class: "diag-rows" };
var _hoisted_7$1 = { class: "diag-row" };
var _hoisted_8$1 = { class: "diag-val" };
var _hoisted_9$1 = { class: "diag-row" };
var _hoisted_10$1 = { class: "diag-val" };
var _hoisted_11$1 = { class: "diag-section" };
var _hoisted_12$1 = {
	key: 0,
	class: "diag-rows"
};
var _hoisted_13$1 = { class: "diag-row" };
var _hoisted_14$1 = { class: "diag-val" };
var _hoisted_15$1 = { class: "diag-row" };
var _hoisted_16$1 = { class: "diag-val" };
var _hoisted_17$1 = { class: "diag-row" };
var _hoisted_18$1 = { class: "diag-val" };
var _hoisted_19$1 = { class: "diag-row" };
var _hoisted_20$1 = { class: "diag-val" };
var _hoisted_21$1 = { class: "diag-row" };
var _hoisted_22$1 = { class: "diag-val" };
var _hoisted_23$1 = { class: "diag-row" };
var _hoisted_24$1 = { class: "diag-val" };
var _hoisted_25$1 = {
	key: 1,
	class: "diag-error"
};
var _hoisted_26$1 = {
	key: 2,
	class: "diag-loading"
};
var _hoisted_27$1 = {
	key: 0,
	class: "diag-section"
};
var _hoisted_28$1 = { class: "diag-rows" };
var _hoisted_29$1 = { class: "diag-test-icon" };
var _hoisted_30$1 = { class: "diag-test-name" };
var _hoisted_31$1 = {
	key: 0,
	class: "diag-test-ms"
};
var _hoisted_32$1 = {
	key: 1,
	class: "diag-test-detail"
};
//#endregion
//#region entrypoints/popup/components/Diagnostic.vue
var Diagnostic_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "Diagnostic",
	props: { port: {} },
	setup(__props) {
		const props = __props;
		const env = ref({
			ua: "",
			chrome: "",
			extensionVersion: "",
			manifestVersion: 3
		});
		const health = ref(null);
		const healthError = ref(null);
		const selfTestRunning = ref(false);
		const expanded = ref(false);
		const selfTestResults = ref([]);
		const base = computed(() => `http://127.0.0.1:${props.port}`);
		const detectEnv = () => {
			var _navigator$userAgent$, _navigator$userAgent$2, _manifest$version, _manifest$manifest_ve;
			const manifest = chrome.runtime.getManifest();
			env.value = {
				ua: navigator.userAgent,
				chrome: (_navigator$userAgent$ = (_navigator$userAgent$2 = navigator.userAgent.match(/Chrome\/(\S+)/)) === null || _navigator$userAgent$2 === void 0 ? void 0 : _navigator$userAgent$2[1]) !== null && _navigator$userAgent$ !== void 0 ? _navigator$userAgent$ : "unknown",
				extensionVersion: (_manifest$version = manifest.version) !== null && _manifest$version !== void 0 ? _manifest$version : "unknown",
				manifestVersion: (_manifest$manifest_ve = manifest.manifest_version) !== null && _manifest$manifest_ve !== void 0 ? _manifest$manifest_ve : 3
			};
		};
		const probeHealth = function() {
			var _ref = _asyncToGenerator(function* () {
				healthError.value = null;
				try {
					const res = yield fetch(`${base.value}/health`, {
						method: "GET",
						signal: AbortSignal.timeout(2e3)
					});
					if (!res.ok) {
						healthError.value = `HTTP ${res.status}`;
						health.value = null;
						return;
					}
					health.value = yield res.json();
				} catch (e) {
					healthError.value = (e === null || e === void 0 ? void 0 : e.message) || String(e);
					health.value = null;
				}
			});
			return function probeHealth() {
				return _ref.apply(this, arguments);
			};
		}();
		const fmtUptime = (ms) => {
			if (!ms) return "?";
			const s = Math.floor(ms / 1e3);
			if (s < 60) return `${s}s`;
			const m = Math.floor(s / 60);
			const rs = s % 60;
			if (m < 60) return `${m}m ${rs}s`;
			return `${Math.floor(m / 60)}h ${m % 60}m`;
		};
		const initializeOnce = function() {
			var _ref2 = _asyncToGenerator(function* () {
				const t0 = Date.now();
				try {
					var _res$headers$get;
					const res = yield fetch(`${base.value}/mcp`, {
						method: "POST",
						headers: {
							"Content-Type": "application/json",
							Accept: "application/json, text/event-stream"
						},
						body: JSON.stringify({
							jsonrpc: "2.0",
							id: `selftest-${t0}-${Math.random().toString(36).slice(2, 8)}`,
							method: "initialize",
							params: {
								protocolVersion: "2024-11-05",
								capabilities: {},
								clientInfo: {
									name: "scalemaker-selftest",
									version: "1.0.0"
								}
							}
						}),
						signal: AbortSignal.timeout(5e3)
					});
					const ms = Date.now() - t0;
					const sid = (_res$headers$get = res.headers.get("mcp-session-id")) !== null && _res$headers$get !== void 0 ? _res$headers$get : void 0;
					return {
						ok: res.ok && !!sid,
						sid,
						ms
					};
				} catch (e) {
					return {
						ok: false,
						ms: Date.now() - t0,
						err: (e === null || e === void 0 ? void 0 : e.message) || String(e)
					};
				}
			});
			return function initializeOnce() {
				return _ref2.apply(this, arguments);
			};
		}();
		const runSelfTest = function() {
			var _ref3 = _asyncToGenerator(function* () {
				var _r1$sid, _r2$sid, _health$value, _health$value2, _healthError$value;
				if (selfTestRunning.value) return;
				selfTestRunning.value = true;
				selfTestResults.value = [
					{
						name: "#1 initialize 첫 회",
						status: "pending"
					},
					{
						name: "#2 initialize 두 번째 (다른 세션 살아있음)",
						status: "pending"
					},
					{
						name: "#3 /health 가 bridge.pid 응답",
						status: "pending"
					},
					{
						name: "#5 Chrome 144+ pagehide 이벤트 (정보)",
						status: "pending"
					},
					{
						name: "#8 CHROME_MCP_HOST 환경변수 (정보)",
						status: "pending"
					}
				];
				const r1 = yield initializeOnce();
				selfTestResults.value[0] = {
					name: "#1 initialize 첫 회",
					status: r1.ok ? "pass" : "fail",
					ms: r1.ms,
					detail: r1.ok ? `세션 ${(_r1$sid = r1.sid) === null || _r1$sid === void 0 ? void 0 : _r1$sid.slice(0, 8)}…` : r1.err
				};
				const r2 = yield initializeOnce();
				const distinct = r1.ok && r2.ok && r1.sid !== r2.sid;
				selfTestResults.value[1] = {
					name: "#2 initialize 두 번째 (다른 세션 살아있음)",
					status: distinct ? "pass" : "fail",
					ms: r2.ms,
					detail: r2.ok ? distinct ? `세션 ${(_r2$sid = r2.sid) === null || _r2$sid === void 0 ? void 0 : _r2$sid.slice(0, 8)}… (≠ #1)` : `#1 과 같은 sid — factory 패턴 미적용!` : r2.err
				};
				yield probeHealth();
				selfTestResults.value[2] = {
					name: "#3 /health 가 bridge.pid 응답",
					status: ((_health$value = health.value) === null || _health$value === void 0 || (_health$value = _health$value.bridge) === null || _health$value === void 0 ? void 0 : _health$value.pid) ? "pass" : "fail",
					detail: ((_health$value2 = health.value) === null || _health$value2 === void 0 || (_health$value2 = _health$value2.bridge) === null || _health$value2 === void 0 ? void 0 : _health$value2.pid) ? `pid ${health.value.bridge.pid}` : (_healthError$value = healthError.value) !== null && _healthError$value !== void 0 ? _healthError$value : "pid 없음"
				};
				selfTestResults.value[3] = {
					name: "#5 Chrome 144+ pagehide 이벤트 (정보)",
					status: "skip",
					detail: "static check: PR #329 흡수됨 (UPSTREAM_DIFF.md 참조)"
				};
				selfTestResults.value[4] = {
					name: "#8 CHROME_MCP_HOST 환경변수 (정보)",
					status: "skip",
					detail: "src/constant/index.test.ts 단위 테스트 10개 통과"
				};
				selfTestRunning.value = false;
			});
			return function runSelfTest() {
				return _ref3.apply(this, arguments);
			};
		}();
		const copyAsJson = () => {
			var _health$value$bridge, _health$value3, _health$value$transpo, _health$value4;
			const payload = {
				fork: "mcp-chrome-scalemaker",
				extension_version: env.value.extensionVersion,
				env: {
					ua: env.value.ua,
					chrome: env.value.chrome,
					manifest_version: env.value.manifestVersion
				},
				bridge: (_health$value$bridge = (_health$value3 = health.value) === null || _health$value3 === void 0 ? void 0 : _health$value3.bridge) !== null && _health$value$bridge !== void 0 ? _health$value$bridge : null,
				bridge_error: healthError.value,
				transports: (_health$value$transpo = (_health$value4 = health.value) === null || _health$value4 === void 0 ? void 0 : _health$value4.transports) !== null && _health$value$transpo !== void 0 ? _health$value$transpo : null,
				self_test: selfTestResults.value,
				captured_at: (/* @__PURE__ */ new Date()).toISOString()
			};
			navigator.clipboard.writeText(JSON.stringify(payload, null, 2)).then(() => alert("진단 JSON 이 클립보드에 복사되었습니다")).catch((e) => alert(`복사 실패: ${e}`));
		};
		onMounted(_asyncToGenerator(function* () {
			detectEnv();
			yield probeHealth();
		}));
		return (_ctx, _cache) => {
			var _health$value$bridge2, _health$value$bridge3, _health$value$bridge4, _health$value$bridge5, _health$value$transpo2, _health$value$transpo3;
			return openBlock(), createElementBlock("div", _hoisted_1$1, [createBaseVNode("div", {
				class: "diag-header diag-header--toggle",
				onClick: _cache[1] || (_cache[1] = ($event) => expanded.value = !expanded.value)
			}, [createBaseVNode("h3", _hoisted_2$1, [createBaseVNode("span", { class: normalizeClass(["diag-chevron", { "diag-chevron--open": expanded.value }]) }, "▶", 2), _cache[2] || (_cache[2] = createTextVNode(" 🔬 진단 리포트 ", -1))]), expanded.value ? (openBlock(), createElementBlock("div", {
				key: 0,
				class: "diag-actions",
				onClick: _cache[0] || (_cache[0] = withModifiers(() => {}, ["stop"]))
			}, [createBaseVNode("button", {
				class: "diag-btn diag-btn-secondary",
				onClick: copyAsJson
			}, "JSON 복사"), createBaseVNode("button", {
				class: "diag-btn",
				disabled: selfTestRunning.value,
				onClick: runSelfTest
			}, toDisplayString(selfTestRunning.value ? "실행 중…" : "자가 진단 실행"), 9, _hoisted_3$1)])) : createCommentVNode("", true)]), expanded.value ? (openBlock(), createElementBlock("div", _hoisted_4$1, [
				createBaseVNode("section", _hoisted_5$1, [_cache[5] || (_cache[5] = createBaseVNode("h4", { class: "diag-section-title" }, "환경", -1)), createBaseVNode("div", _hoisted_6$1, [createBaseVNode("div", _hoisted_7$1, [_cache[3] || (_cache[3] = createBaseVNode("span", { class: "diag-key" }, "Chrome", -1)), createBaseVNode("span", _hoisted_8$1, toDisplayString(env.value.chrome), 1)]), createBaseVNode("div", _hoisted_9$1, [_cache[4] || (_cache[4] = createBaseVNode("span", { class: "diag-key" }, "확장", -1)), createBaseVNode("span", _hoisted_10$1, "v" + toDisplayString(env.value.extensionVersion) + " (MV" + toDisplayString(env.value.manifestVersion) + ")", 1)])])]),
				createBaseVNode("section", _hoisted_11$1, [_cache[12] || (_cache[12] = createBaseVNode("h4", { class: "diag-section-title" }, "브릿지 프로세스", -1)), health.value ? (openBlock(), createElementBlock("div", _hoisted_12$1, [
					createBaseVNode("div", _hoisted_13$1, [_cache[6] || (_cache[6] = createBaseVNode("span", { class: "diag-key" }, "Fork", -1)), createBaseVNode("span", _hoisted_14$1, toDisplayString(health.value.fork) + "@" + toDisplayString(health.value.version), 1)]),
					createBaseVNode("div", _hoisted_15$1, [_cache[7] || (_cache[7] = createBaseVNode("span", { class: "diag-key" }, "PID", -1)), createBaseVNode("span", _hoisted_16$1, toDisplayString((_health$value$bridge2 = health.value.bridge) === null || _health$value$bridge2 === void 0 ? void 0 : _health$value$bridge2.pid), 1)]),
					createBaseVNode("div", _hoisted_17$1, [_cache[8] || (_cache[8] = createBaseVNode("span", { class: "diag-key" }, "가동 시간", -1)), createBaseVNode("span", _hoisted_18$1, toDisplayString(fmtUptime((_health$value$bridge3 = health.value.bridge) === null || _health$value$bridge3 === void 0 ? void 0 : _health$value$bridge3.uptime_ms)), 1)]),
					createBaseVNode("div", _hoisted_19$1, [_cache[9] || (_cache[9] = createBaseVNode("span", { class: "diag-key" }, "메모리", -1)), createBaseVNode("span", _hoisted_20$1, toDisplayString((_health$value$bridge4 = health.value.bridge) === null || _health$value$bridge4 === void 0 ? void 0 : _health$value$bridge4.memory_mb) + " MB", 1)]),
					createBaseVNode("div", _hoisted_21$1, [_cache[10] || (_cache[10] = createBaseVNode("span", { class: "diag-key" }, "Node", -1)), createBaseVNode("span", _hoisted_22$1, toDisplayString((_health$value$bridge5 = health.value.bridge) === null || _health$value$bridge5 === void 0 ? void 0 : _health$value$bridge5.node), 1)]),
					createBaseVNode("div", _hoisted_23$1, [_cache[11] || (_cache[11] = createBaseVNode("span", { class: "diag-key" }, "활성 transport 수", -1)), createBaseVNode("span", _hoisted_24$1, toDisplayString((_health$value$transpo2 = (_health$value$transpo3 = health.value.transports) === null || _health$value$transpo3 === void 0 ? void 0 : _health$value$transpo3.active_count) !== null && _health$value$transpo2 !== void 0 ? _health$value$transpo2 : 0), 1)])
				])) : healthError.value ? (openBlock(), createElementBlock("div", _hoisted_25$1, " ❌ " + toDisplayString(healthError.value) + " — " + toDisplayString(base.value) + "/health 에 접근 불가 ", 1)) : (openBlock(), createElementBlock("div", _hoisted_26$1, "⏳ /health 응답 대기 중…"))]),
				selfTestResults.value.length > 0 ? (openBlock(), createElementBlock("section", _hoisted_27$1, [_cache[13] || (_cache[13] = createBaseVNode("h4", { class: "diag-section-title" }, "자가 진단 (DESIGN.md §3 회귀 케이스)", -1)), createBaseVNode("div", _hoisted_28$1, [(openBlock(true), createElementBlock(Fragment, null, renderList(selfTestResults.value, (r, i) => {
					return openBlock(), createElementBlock("div", {
						key: i,
						class: normalizeClass(["diag-test-row", `diag-test-row--${r.status}`])
					}, [
						createBaseVNode("span", _hoisted_29$1, toDisplayString(r.status === "pass" ? "✅" : r.status === "fail" ? "❌" : r.status === "skip" ? "⏭️" : "⏳"), 1),
						createBaseVNode("span", _hoisted_30$1, toDisplayString(r.name), 1),
						r.ms ? (openBlock(), createElementBlock("span", _hoisted_31$1, toDisplayString(r.ms) + "ms", 1)) : createCommentVNode("", true),
						r.detail ? (openBlock(), createElementBlock("div", _hoisted_32$1, toDisplayString(r.detail), 1)) : createCommentVNode("", true)
					], 2);
				}), 128))])])) : createCommentVNode("", true)
			])) : createCommentVNode("", true)]);
		};
	}
}), [["__scopeId", "data-v-e71522ff"]]);
//#endregion
//#region entrypoints/popup/App.vue?vue&type=script&setup=true&lang.ts
init_asyncToGenerator();
var _hoisted_1 = ["data-agent-theme"];
var _hoisted_2 = { class: "home-view" };
var _hoisted_3 = { class: "content" };
var _hoisted_4 = { class: "section" };
var _hoisted_5 = { class: "section-title" };
var _hoisted_6 = { class: "config-card" };
var _hoisted_7 = { class: "status-section" };
var _hoisted_8 = { class: "status-header" };
var _hoisted_9 = { class: "status-label" };
var _hoisted_10 = { class: "status-switches" };
var _hoisted_11 = ["title"];
var _hoisted_12 = ["checked", "aria-label"];
var _hoisted_13 = {
	class: "force-focus-switch",
	title: "ON: MCP 도구가 사용자의 탭·포커스를 건드리지 않고 백그라운드 작업 탭에서 작업합니다. OFF: 이전처럼 작업 탭을 앞으로 가져옵니다."
};
var _hoisted_14 = ["checked", "aria-label"];
var _hoisted_15 = {
	class: "force-focus-switch",
	title: "ON: MCP 작업 탭을 별도 'MCP 작업 창'에 모아서 사용자 창과 분리합니다. OFF: 현재 창에 백그라운드 탭으로 만듭니다."
};
var _hoisted_16 = ["checked", "aria-label"];
var _hoisted_17 = { class: "status-info" };
var _hoisted_18 = { class: "status-text" };
var _hoisted_19 = {
	key: 0,
	class: "status-timestamp"
};
var _hoisted_20 = {
	key: 0,
	class: "mcp-config-section"
};
var _hoisted_21 = { class: "mcp-config-content" };
var _hoisted_22 = { class: "mcp-config-json" };
var _hoisted_23 = { class: "port-section" };
var _hoisted_24 = {
	for: "port",
	class: "port-label"
};
var _hoisted_25 = ["value"];
var _hoisted_26 = ["disabled"];
var _hoisted_27 = { class: "section" };
var _hoisted_28 = { class: "config-card" };
var _hoisted_29 = { class: "site-perms-list" };
var _hoisted_30 = { class: "site-perms-row" };
var _hoisted_31 = { class: "site-perms-row__label" };
var _hoisted_32 = {
	class: "site-perms-row__icon",
	"aria-hidden": "true"
};
var _hoisted_33 = { class: "site-perms-row__actions" };
var _hoisted_34 = [
	"title",
	"aria-label",
	"onClick"
];
var _hoisted_35 = { class: "force-focus-switch__wrap" };
var _hoisted_36 = [
	"checked",
	"aria-label",
	"onChange"
];
var _hoisted_37 = {
	key: 0,
	class: "coming-soon-toast"
};
//#endregion
//#region entrypoints/popup/App.vue
var App_default = /* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "App",
	setup(__props) {
		const { theme: agentTheme, initTheme } = useAgentTheme();
		const currentView = ref("home");
		const comingSoonToast = ref({
			show: false,
			feature: ""
		});
		function showComingSoonToast(feature) {
			comingSoonToast.value = {
				show: true,
				feature
			};
			setTimeout(() => {
				comingSoonToast.value = {
					show: false,
					feature: ""
				};
			}, 2e3);
		}
		ref(false);
		const rrFlows = ref([]);
		const rrOnlyBound = ref(false);
		const rrSearch = ref("");
		const currentTabUrl = ref("");
		computed(() => {
			const base = rrOnlyBound.value ? rrFlows.value.filter(isFlowBoundToCurrent) : rrFlows.value;
			const q = rrSearch.value.trim().toLowerCase();
			if (!q) return base;
			return base.filter((f) => {
				var _f$meta, _f$meta2;
				const name = String(f.name || "").toLowerCase();
				const domain = String((f === null || f === void 0 || (_f$meta = f.meta) === null || _f$meta === void 0 ? void 0 : _f$meta.domain) || "").toLowerCase();
				const tags = ((f === null || f === void 0 || (_f$meta2 = f.meta) === null || _f$meta2 === void 0 ? void 0 : _f$meta2.tags) || []).join(",").toLowerCase();
				return name.includes(q) || domain.includes(q) || tags.includes(q);
			});
		});
		const loadFlows = function() {
			var _ref = _asyncToGenerator(function* () {
				try {
					const res = yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.RR_LIST_FLOWS });
					if (res && res.success) rrFlows.value = res.flows || [];
				} catch (e) {}
			});
			return function loadFlows() {
				return _ref.apply(this, arguments);
			};
		}();
		function isFlowBoundToCurrent(flow) {
			try {
				var _flow$meta;
				const bindings = (flow === null || flow === void 0 || (_flow$meta = flow.meta) === null || _flow$meta === void 0 ? void 0 : _flow$meta.bindings) || [];
				if (!bindings.length) return false;
				if (!currentTabUrl.value) return true;
				const url = new URL(currentTabUrl.value);
				return bindings.some((b) => {
					if (b.type === "domain") return url.hostname.includes(b.value);
					if (b.type === "path") return url.pathname.startsWith(b.value);
					if (b.type === "url") return (url.href || "").startsWith(b.value);
					return false;
				});
			} catch (_unused) {
				return false;
			}
		}
		(function() {
			var _ref2 = _asyncToGenerator(function* () {
				showComingSoonToast("录制回放");
			});
			return function startRecording() {
				return _ref2.apply(this, arguments);
			};
		})();
		(function() {
			var _ref3 = _asyncToGenerator(function* () {
				showComingSoonToast("录制回放");
			});
			return function stopRecording() {
				return _ref3.apply(this, arguments);
			};
		})();
		(function() {
			var _ref4 = _asyncToGenerator(function* (flowId) {
				try {
					let flow = null;
					try {
						const getRes = yield chrome.runtime.sendMessage({
							type: BACKGROUND_MESSAGE_TYPES.RR_GET_FLOW,
							flowId
						});
						if (getRes && getRes.success) flow = getRes.flow;
					} catch (_unused2) {}
					const runOptions = flow && flow.meta && flow.meta.runOptions || {};
					const res = yield chrome.runtime.sendMessage({
						type: BACKGROUND_MESSAGE_TYPES.RR_RUN_FLOW,
						flowId,
						options: _objectSpread2(_objectSpread2(_objectSpread2({}, runOptions), {}), {}, { returnLogs: true })
					});
					if (!(res && res.success)) {
						console.warn("回放失败");
						return;
					}
					try {
						const result = res.result;
						if (result && result.success === false) {
							const failed = (result.logs || []).find((l) => l.status === "failed");
							if (failed && failed.stepId) {
								if (flow) openBuilderWindow(flow.id, String(failed.stepId));
							}
						} else if (result && result.success === true) {
							const fb = (result.logs || []).find((l) => l.fallbackUsed && l.fallbackTo);
							if (fb && flow) openBuilderWindow(flow.id, String(fb.stepId || ""));
						}
					} catch (_unused3) {}
				} catch (e) {
					console.error("回放失败:", e);
				}
			});
			return function runFlow(_x) {
				return _ref4.apply(this, arguments);
			};
		})();
		const nativeConnectionStatus = ref("unknown");
		const isConnecting = ref(false);
		const nativeServerPort = ref(12320);
		const forceFocusEnabled = ref(false);
		const backgroundModeEnabled = ref(true);
		const dedicatedWindowEnabled = ref(true);
		const sitePermissionToggles = ref({
			camera: true,
			microphone: true,
			geolocation: true
		});
		const SITE_PERMISSION_ITEMS = [
			{
				key: "camera",
				label: "카메라",
				icon: "📷"
			},
			{
				key: "microphone",
				label: "마이크",
				icon: "🎤"
			},
			{
				key: "geolocation",
				label: "위치 정보",
				icon: "📍"
			}
		];
		const OS_PERMISSION_URLS = {
			mac: {
				camera: "x-apple.systempreferences:com.apple.preference.security?Privacy_Camera",
				microphone: "x-apple.systempreferences:com.apple.preference.security?Privacy_Microphone",
				geolocation: "x-apple.systempreferences:com.apple.preference.security?Privacy_LocationServices"
			},
			win: {
				camera: "ms-settings:privacy-webcam",
				microphone: "ms-settings:privacy-microphone",
				geolocation: "ms-settings:privacy-location"
			}
		};
		const serverStatus = ref({
			isRunning: false,
			lastUpdated: Date.now()
		});
		const showMcpConfig = computed(() => {
			return nativeConnectionStatus.value === "connected" && serverStatus.value.isRunning;
		});
		const claudePromptText = computed(() => {
			return `지금 working dir (이 프로젝트 폴더) 의 .mcp.json 에 우리 chrome MCP (mcp-chrome-scalemaker) 를 등록해줘. ~/.claude.json 같은 전역 설정에는 손대지 마.

규칙:
- 이름: "chrome-mcp-stdio"
- transport: stdio (HTTP 안 씀)
- command: "node"
- args: ["<npm root -g 출력값>/mcp-chrome-scalemaker-bridge/dist/mcp/mcp-server-stdio.js"]
- env: { "CHROME_PORT": "${serverStatus.value.port || nativeServerPort.value}" }\n\n먼저 \`npm root -g\` 를 bash 로 실행해서 실제 경로 얻고, 그 다음에 working dir 의 .mcp.json (없으면 신설) 의 mcpServers.chrome-mcp-stdio 만 추가/갱신해줘. 기존 다른 server 항목은 보존.

등록이 끝나면 아래 절차도 함께 안내해줘:
1. Claude Code 를 Ctrl+C 두 번으로 종료 후 다시 실행 (mcp 서버 재로드)
2. \`/mcp\` 입력해서 chrome-mcp-stdio 가 connected 상태인지 확인
3. 확인 후 Esc 로 빠져나오기`;
		});
		const claudePromptCopyText = ref("복사하기");
		const copyClaudePrompt = function() {
			var _ref5 = _asyncToGenerator(function* () {
				try {
					yield navigator.clipboard.writeText(claudePromptText.value);
					claudePromptCopyText.value = "✅ 복사됨";
					setTimeout(() => {
						claudePromptCopyText.value = "복사하기";
					}, 2e3);
				} catch (e) {
					console.error("Failed to copy claude prompt:", e);
				}
			});
			return function copyClaudePrompt() {
				return _ref5.apply(this, arguments);
			};
		}();
		const currentModel = ref(null);
		const isModelSwitching = ref(false);
		const modelSwitchProgress = ref("");
		const modelDownloadProgress = ref(0);
		const isModelDownloading = ref(false);
		const modelInitializationStatus = ref("idle");
		const modelErrorMessage = ref("");
		const modelErrorType = ref("");
		const selectedVersion = ref("quantized");
		const storageStats = ref(null);
		const isRefreshingStats = ref(false);
		const isClearingData = ref(false);
		const showClearConfirmation = ref(false);
		const clearDataProgress = ref("");
		const semanticEngineStatus = ref("idle");
		const isSemanticEngineInitializing = ref(false);
		const semanticEngineInitProgress = ref("");
		const semanticEngineLastUpdated = ref(null);
		const isManagingCache = ref(false);
		const cacheStats = ref(null);
		const availableModels = computed(() => {
			return Object.entries(PREDEFINED_MODELS).map(([key, value]) => _objectSpread2({ preset: key }, value));
		});
		const getStatusClass = () => {
			if (nativeConnectionStatus.value === "connected") if (serverStatus.value.isRunning) return "bg-emerald-500";
			else return "bg-yellow-500";
			else if (nativeConnectionStatus.value === "disconnected") return "bg-red-500";
			else return "bg-gray-500";
		};
		function _openSidepanelAndClose() {
			_openSidepanelAndClose = _asyncToGenerator(function* (tab) {
				try {
					var _chrome$sidePanel;
					const current = yield chrome.windows.getCurrent();
					if ((_chrome$sidePanel = chrome.sidePanel) === null || _chrome$sidePanel === void 0 ? void 0 : _chrome$sidePanel.setOptions) yield chrome.sidePanel.setOptions({
						path: `sidepanel.html?tab=${tab}`,
						enabled: true
					});
					if (chrome.sidePanel && chrome.sidePanel.open) yield chrome.sidePanel.open({ windowId: current.id });
					window.close();
				} catch (e) {
					console.warn(`Failed to open sidepanel (${tab}):`, e);
				}
			});
			return _openSidepanelAndClose.apply(this, arguments);
		}
		function _toggleWebEditor() {
			_toggleWebEditor = _asyncToGenerator(function* () {
				try {
					yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.WEB_EDITOR_TOGGLE });
				} catch (error) {
					console.warn("切换网页编辑模式失败:", error);
				}
			});
			return _toggleWebEditor.apply(this, arguments);
		}
		function _toggleElementMarker() {
			_toggleElementMarker = _asyncToGenerator(function* () {
				try {
					const [tab] = yield chrome.tabs.query({
						active: true,
						currentWindow: true
					});
					if (!(tab === null || tab === void 0 ? void 0 : tab.id)) {
						console.warn("无法获取当前tab");
						return;
					}
					yield chrome.runtime.sendMessage({
						type: BACKGROUND_MESSAGE_TYPES.ELEMENT_MARKER_START,
						tabId: tab.id
					});
				} catch (error) {
					console.warn("开启元素标注失败:", error);
				}
			});
			return _toggleElementMarker.apply(this, arguments);
		}
		function _openWelcomePage() {
			_openWelcomePage = _asyncToGenerator(function* () {
				try {
					yield chrome.tabs.create({ url: chrome.runtime.getURL("welcome.html") });
				} catch (_unused4) {}
			});
			return _openWelcomePage.apply(this, arguments);
		}
		function openBuilderWindow(flowId, focusNodeId) {
			const url = new URL(chrome.runtime.getURL("builder.html"));
			if (flowId) url.searchParams.set("flowId", flowId);
			if (focusNodeId) url.searchParams.set("focus", focusNodeId);
			chrome.windows.create({
				url: url.toString(),
				type: "popup",
				width: 1280,
				height: 800
			});
		}
		const getStatusText = () => {
			if (nativeConnectionStatus.value === "connected") if (serverStatus.value.isRunning) return getMessage("serviceRunningStatus", [(serverStatus.value.port || "Unknown").toString()]);
			else return getMessage("connectedServiceNotStartedStatus");
			else if (nativeConnectionStatus.value === "disconnected") return getMessage("serviceNotConnectedStatus");
			else return getMessage("detectingStatus");
		};
		const loadCacheStats = function() {
			var _ref6 = _asyncToGenerator(function* () {
				try {
					cacheStats.value = yield getCacheStats();
				} catch (error) {
					console.error("Failed to get cache stats:", error);
					cacheStats.value = null;
				}
			});
			return function loadCacheStats() {
				return _ref6.apply(this, arguments);
			};
		}();
		const cleanupCache = function() {
			var _ref7 = _asyncToGenerator(function* () {
				if (isManagingCache.value) return;
				isManagingCache.value = true;
				try {
					yield cleanupModelCache();
					yield loadCacheStats();
				} catch (error) {
					console.error("Failed to cleanup cache:", error);
				} finally {
					isManagingCache.value = false;
				}
			});
			return function cleanupCache() {
				return _ref7.apply(this, arguments);
			};
		}();
		const clearAllCache = function() {
			var _ref8 = _asyncToGenerator(function* () {
				if (isManagingCache.value) return;
				isManagingCache.value = true;
				try {
					yield clearModelCache();
					yield loadCacheStats();
				} catch (error) {
					console.error("Failed to clear cache:", error);
				} finally {
					isManagingCache.value = false;
				}
			});
			return function clearAllCache() {
				return _ref8.apply(this, arguments);
			};
		}();
		const saveSemanticEngineState = function() {
			var _ref9 = _asyncToGenerator(function* () {
				try {
					const semanticEngineState = {
						status: semanticEngineStatus.value,
						lastUpdated: semanticEngineLastUpdated.value
					};
					yield chrome.storage.local.set({ semanticEngineState });
				} catch (error) {
					console.error("保存语义引擎状态失败:", error);
				}
			});
			return function saveSemanticEngineState() {
				return _ref9.apply(this, arguments);
			};
		}();
		const initializeSemanticEngine = function() {
			var _ref10 = _asyncToGenerator(function* () {
				if (isSemanticEngineInitializing.value) return;
				const isReinitialization = semanticEngineStatus.value === "ready";
				console.log(`🚀 User triggered semantic engine ${isReinitialization ? "reinitialization" : "initialization"}`);
				isSemanticEngineInitializing.value = true;
				semanticEngineStatus.value = "initializing";
				semanticEngineInitProgress.value = isReinitialization ? getMessage("semanticEngineInitializingStatus") : getMessage("semanticEngineInitializingStatus");
				semanticEngineLastUpdated.value = Date.now();
				yield saveSemanticEngineState();
				try {
					chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.INITIALIZE_SEMANTIC_ENGINE }).catch((error) => {
						console.error("❌ Error sending semantic engine initialization request:", error);
					});
					startSemanticEngineStatusPolling();
					semanticEngineInitProgress.value = isReinitialization ? getMessage("processingStatus") : getMessage("processingStatus");
				} catch (error) {
					console.error("❌ Failed to send initialization request:", error);
					semanticEngineStatus.value = "error";
					semanticEngineInitProgress.value = `Failed to send initialization request: ${(error === null || error === void 0 ? void 0 : error.message) || "Unknown error"}`;
					yield saveSemanticEngineState();
					setTimeout(() => {
						semanticEngineInitProgress.value = "";
					}, 5e3);
					isSemanticEngineInitializing.value = false;
					semanticEngineLastUpdated.value = Date.now();
					yield saveSemanticEngineState();
				}
			});
			return function initializeSemanticEngine() {
				return _ref10.apply(this, arguments);
			};
		}();
		const checkSemanticEngineStatus = function() {
			var _ref11 = _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.GET_MODEL_STATUS });
					if (response && response.success && response.status) {
						const status = response.status;
						if (status.initializationStatus === "ready") {
							semanticEngineStatus.value = "ready";
							semanticEngineLastUpdated.value = Date.now();
							isSemanticEngineInitializing.value = false;
							semanticEngineInitProgress.value = getMessage("semanticEngineReadyStatus");
							yield saveSemanticEngineState();
							stopSemanticEngineStatusPolling();
							setTimeout(() => {
								semanticEngineInitProgress.value = "";
							}, 2e3);
						} else if (status.initializationStatus === "downloading" || status.initializationStatus === "initializing") {
							semanticEngineStatus.value = "initializing";
							isSemanticEngineInitializing.value = true;
							semanticEngineInitProgress.value = getMessage("semanticEngineInitializingStatus");
							semanticEngineLastUpdated.value = Date.now();
							yield saveSemanticEngineState();
						} else if (status.initializationStatus === "error") {
							semanticEngineStatus.value = "error";
							semanticEngineLastUpdated.value = Date.now();
							isSemanticEngineInitializing.value = false;
							semanticEngineInitProgress.value = getMessage("semanticEngineInitFailedStatus");
							yield saveSemanticEngineState();
							stopSemanticEngineStatusPolling();
							setTimeout(() => {
								semanticEngineInitProgress.value = "";
							}, 5e3);
						} else {
							semanticEngineStatus.value = "idle";
							isSemanticEngineInitializing.value = false;
							yield saveSemanticEngineState();
						}
					} else {
						semanticEngineStatus.value = "idle";
						isSemanticEngineInitializing.value = false;
						yield saveSemanticEngineState();
					}
				} catch (error) {
					console.error("Popup: Failed to check semantic engine status:", error);
					semanticEngineStatus.value = "idle";
					isSemanticEngineInitializing.value = false;
					yield saveSemanticEngineState();
				}
			});
			return function checkSemanticEngineStatus() {
				return _ref11.apply(this, arguments);
			};
		}();
		const retryModelInitialization = function() {
			var _ref12 = _asyncToGenerator(function* () {
				if (!currentModel.value) return;
				console.log("🔄 Retrying model initialization...");
				modelErrorMessage.value = "";
				modelErrorType.value = "";
				modelInitializationStatus.value = "downloading";
				modelDownloadProgress.value = 0;
				isModelDownloading.value = true;
				yield switchModel(currentModel.value);
			});
			return function retryModelInitialization() {
				return _ref12.apply(this, arguments);
			};
		}();
		const updatePort = function() {
			var _ref13 = _asyncToGenerator(function* (event) {
				const target = event.target;
				const newPort = Number(target.value);
				nativeServerPort.value = newPort;
				yield savePortPreference(newPort);
			});
			return function updatePort(_x3) {
				return _ref13.apply(this, arguments);
			};
		}();
		const checkNativeConnection = function() {
			var _ref14 = _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: "ping_native" });
					nativeConnectionStatus.value = (response === null || response === void 0 ? void 0 : response.connected) ? "connected" : "disconnected";
				} catch (error) {
					console.error("检测 Native 连接状态失败:", error);
					nativeConnectionStatus.value = "disconnected";
				}
			});
			return function checkNativeConnection() {
				return _ref14.apply(this, arguments);
			};
		}();
		const checkServerStatus = function() {
			var _ref15 = _asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: BACKGROUND_MESSAGE_TYPES.GET_SERVER_STATUS });
					if ((response === null || response === void 0 ? void 0 : response.success) && response.serverStatus) serverStatus.value = response.serverStatus;
					if ((response === null || response === void 0 ? void 0 : response.connected) !== void 0) nativeConnectionStatus.value = response.connected ? "connected" : "disconnected";
				} catch (error) {
					console.error("检测服务器状态失败:", error);
				}
			});
			return function checkServerStatus() {
				return _ref15.apply(this, arguments);
			};
		}();
		const handleReconnected = function() {
			var _ref16 = _asyncToGenerator(function* (payload) {
				if (!payload.ok) return;
				nativeConnectionStatus.value = "connected";
				serverStatus.value = _objectSpread2(_objectSpread2({}, serverStatus.value), {}, {
					isRunning: true,
					port: Number(nativeServerPort.value) || 12320,
					lastUpdated: Date.now()
				});
				try {
					yield chrome.runtime.sendMessage({ type: "connectNative" });
				} catch (_unused5) {}
				yield Promise.all([checkNativeConnection(), checkServerStatus()]).catch(() => {});
				setTimeout(() => {
					if (payload.ok) {
						nativeConnectionStatus.value = "connected";
						serverStatus.value = _objectSpread2(_objectSpread2({}, serverStatus.value), {}, {
							isRunning: true,
							port: Number(nativeServerPort.value) || 12320,
							lastUpdated: Date.now()
						});
					}
				}, 1e3);
			});
			return function handleReconnected(_x4) {
				return _ref16.apply(this, arguments);
			};
		}();
		const testNativeConnection = function() {
			var _ref17 = _asyncToGenerator(function* () {
				if (isConnecting.value) return;
				isConnecting.value = true;
				try {
					if (nativeConnectionStatus.value === "connected") {
						yield chrome.runtime.sendMessage({ type: "disconnect_native" });
						nativeConnectionStatus.value = "disconnected";
					} else {
						console.log(`尝试连接到端口: ${nativeServerPort.value}`);
						const response = yield chrome.runtime.sendMessage({
							type: "connectNative",
							port: nativeServerPort.value
						});
						if (response && response.success) {
							nativeConnectionStatus.value = "connected";
							console.log("连接成功:", response);
							yield savePortPreference(nativeServerPort.value);
						} else {
							nativeConnectionStatus.value = "disconnected";
							console.error("连接失败:", response);
						}
					}
				} catch (error) {
					console.error("测试连接失败:", error);
					nativeConnectionStatus.value = "disconnected";
				} finally {
					isConnecting.value = false;
				}
			});
			return function testNativeConnection() {
				return _ref17.apply(this, arguments);
			};
		}();
		const loadModelPreference = function() {
			var _ref18 = _asyncToGenerator(function* () {
				try {
					const result = yield chrome.storage.local.get([
						"selectedModel",
						"selectedVersion",
						"modelState",
						"semanticEngineState"
					]);
					if (result.selectedModel) {
						const storedModel = result.selectedModel;
						console.log("📋 Stored model from storage:", storedModel);
						if (PREDEFINED_MODELS[storedModel]) {
							currentModel.value = storedModel;
							console.log(`✅ Loaded valid model: ${currentModel.value}`);
						} else {
							console.warn(`⚠️ Stored model "${storedModel}" not found in PREDEFINED_MODELS, using default`);
							currentModel.value = "multilingual-e5-small";
							yield saveModelPreference(currentModel.value);
						}
					} else {
						console.log("⚠️ No model found in storage, using default");
						currentModel.value = "multilingual-e5-small";
						yield saveModelPreference(currentModel.value);
					}
					selectedVersion.value = "quantized";
					console.log("✅ Using quantized version (fixed)");
					yield saveVersionPreference("quantized");
					if (result.modelState) {
						const modelState = result.modelState;
						if (modelState.status === "ready") {
							modelInitializationStatus.value = "ready";
							modelDownloadProgress.value = modelState.downloadProgress || 100;
							isModelDownloading.value = false;
						} else {
							modelInitializationStatus.value = "idle";
							modelDownloadProgress.value = 0;
							isModelDownloading.value = false;
							yield saveModelState();
						}
					} else {
						modelInitializationStatus.value = "idle";
						modelDownloadProgress.value = 0;
						isModelDownloading.value = false;
					}
					if (result.semanticEngineState) {
						const semanticState = result.semanticEngineState;
						if (semanticState.status === "ready") {
							semanticEngineStatus.value = "ready";
							semanticEngineLastUpdated.value = semanticState.lastUpdated || Date.now();
						} else if (semanticState.status === "error") {
							semanticEngineStatus.value = "error";
							semanticEngineLastUpdated.value = semanticState.lastUpdated || Date.now();
						} else semanticEngineStatus.value = "idle";
					} else semanticEngineStatus.value = "idle";
				} catch (error) {
					console.error("❌ 加载模型偏好失败:", error);
				}
			});
			return function loadModelPreference() {
				return _ref18.apply(this, arguments);
			};
		}();
		const saveModelPreference = function() {
			var _ref19 = _asyncToGenerator(function* (model) {
				try {
					yield chrome.storage.local.set({ selectedModel: model });
				} catch (error) {
					console.error("保存模型偏好失败:", error);
				}
			});
			return function saveModelPreference(_x5) {
				return _ref19.apply(this, arguments);
			};
		}();
		const saveVersionPreference = function() {
			var _ref20 = _asyncToGenerator(function* (version) {
				try {
					yield chrome.storage.local.set({ selectedVersion: version });
				} catch (error) {
					console.error("保存版本偏好失败:", error);
				}
			});
			return function saveVersionPreference(_x6) {
				return _ref20.apply(this, arguments);
			};
		}();
		const savePortPreference = function() {
			var _ref21 = _asyncToGenerator(function* (port) {
				try {
					yield chrome.storage.local.set({ nativeServerPort: port });
					console.log(`端口偏好已保存: ${port}`);
				} catch (error) {
					console.error("保存端口偏好失败:", error);
				}
			});
			return function savePortPreference(_x7) {
				return _ref21.apply(this, arguments);
			};
		}();
		const loadPortPreference = function() {
			var _ref22 = _asyncToGenerator(function* () {
				try {
					const result = yield chrome.storage.local.get(["nativeServerPort"]);
					if (result.nativeServerPort) {
						nativeServerPort.value = result.nativeServerPort;
						console.log(`端口偏好已加载: ${result.nativeServerPort}`);
					}
				} catch (error) {
					console.error("加载端口偏好失败:", error);
				}
			});
			return function loadPortPreference() {
				return _ref22.apply(this, arguments);
			};
		}();
		const loadForceFocusPreference = function() {
			var _ref23 = _asyncToGenerator(function* () {
				try {
					forceFocusEnabled.value = yield isForceFocusEnabled();
				} catch (error) {
					console.error("강제포커스 설정 로드 실패:", error);
				}
			});
			return function loadForceFocusPreference() {
				return _ref23.apply(this, arguments);
			};
		}();
		const toggleForceFocus = function() {
			var _ref24 = _asyncToGenerator(function* () {
				const next = !forceFocusEnabled.value;
				forceFocusEnabled.value = next;
				try {
					yield setForceFocusEnabled(next);
				} catch (error) {
					console.error("강제포커스 설정 저장 실패:", error);
					forceFocusEnabled.value = !next;
				}
			});
			return function toggleForceFocus() {
				return _ref24.apply(this, arguments);
			};
		}();
		const loadBackgroundModePreference = function() {
			var _ref25 = _asyncToGenerator(function* () {
				try {
					backgroundModeEnabled.value = yield isBackgroundModeEnabled();
				} catch (error) {
					console.error("백그라운드 작업 모드 설정 로드 실패:", error);
				}
			});
			return function loadBackgroundModePreference() {
				return _ref25.apply(this, arguments);
			};
		}();
		const toggleBackgroundMode = function() {
			var _ref26 = _asyncToGenerator(function* () {
				const next = !backgroundModeEnabled.value;
				backgroundModeEnabled.value = next;
				try {
					yield setBackgroundModeEnabled(next);
				} catch (error) {
					console.error("백그라운드 작업 모드 설정 저장 실패:", error);
					backgroundModeEnabled.value = !next;
				}
			});
			return function toggleBackgroundMode() {
				return _ref26.apply(this, arguments);
			};
		}();
		const loadDedicatedWindowPreference = function() {
			var _ref27 = _asyncToGenerator(function* () {
				try {
					dedicatedWindowEnabled.value = yield isDedicatedWindowEnabled();
				} catch (error) {
					console.error("전용 작업 창 설정 로드 실패:", error);
				}
			});
			return function loadDedicatedWindowPreference() {
				return _ref27.apply(this, arguments);
			};
		}();
		const toggleDedicatedWindow = function() {
			var _ref28 = _asyncToGenerator(function* () {
				const next = !dedicatedWindowEnabled.value;
				dedicatedWindowEnabled.value = next;
				try {
					yield setDedicatedWindowEnabled(next);
				} catch (error) {
					console.error("전용 작업 창 설정 저장 실패:", error);
					dedicatedWindowEnabled.value = !next;
				}
			});
			return function toggleDedicatedWindow() {
				return _ref28.apply(this, arguments);
			};
		}();
		const loadSitePermissionToggles = function() {
			var _ref29 = _asyncToGenerator(function* () {
				try {
					sitePermissionToggles.value = yield getToggles();
				} catch (error) {
					console.error("사이트 권한 토글 로드 실패:", error);
				}
			});
			return function loadSitePermissionToggles() {
				return _ref29.apply(this, arguments);
			};
		}();
		const toggleSitePermission = function() {
			var _ref30 = _asyncToGenerator(function* (key) {
				const next = !sitePermissionToggles.value[key];
				sitePermissionToggles.value = _objectSpread2(_objectSpread2({}, sitePermissionToggles.value), {}, { [key]: next });
				try {
					yield setToggle(key, next);
				} catch (error) {
					console.error("사이트 권한 토글 저장 실패:", error);
					sitePermissionToggles.value = _objectSpread2(_objectSpread2({}, sitePermissionToggles.value), {}, { [key]: !next });
				}
			});
			return function toggleSitePermission(_x8) {
				return _ref30.apply(this, arguments);
			};
		}();
		const openOSPermission = function() {
			var _ref31 = _asyncToGenerator(function* (key) {
				var _SITE_PERMISSION_ITEM;
				const label = ((_SITE_PERMISSION_ITEM = SITE_PERMISSION_ITEMS.find((i) => i.key === key)) === null || _SITE_PERMISSION_ITEM === void 0 ? void 0 : _SITE_PERMISSION_ITEM.label) || key;
				try {
					var _OS_PERMISSION_URLS$i;
					const info = yield chrome.runtime.getPlatformInfo();
					const url = (_OS_PERMISSION_URLS$i = OS_PERMISSION_URLS[info.os]) === null || _OS_PERMISSION_URLS$i === void 0 ? void 0 : _OS_PERMISSION_URLS$i[key];
					if (url) window.location.href = url;
					else alert(`이 OS (${info.os}) 에서는 자동 열기 미지원.\n${label} 권한을 시스템 설정에서 직접 켜주세요.`);
				} catch (e) {
					console.error("openOSPermission 실패:", e);
					alert(`OS 설정 열기 실패. ${label} 권한을 시스템 설정에서 직접 켜주세요.`);
				}
			});
			return function openOSPermission(_x9) {
				return _ref31.apply(this, arguments);
			};
		}();
		const saveModelState = function() {
			var _ref32 = _asyncToGenerator(function* () {
				try {
					const modelState = {
						status: modelInitializationStatus.value,
						downloadProgress: modelDownloadProgress.value,
						isDownloading: isModelDownloading.value,
						lastUpdated: Date.now()
					};
					yield chrome.storage.local.set({ modelState });
				} catch (error) {
					console.error("保存模型状态失败:", error);
				}
			});
			return function saveModelState() {
				return _ref32.apply(this, arguments);
			};
		}();
		let statusMonitoringInterval = null;
		let semanticEngineStatusPollingInterval = null;
		const startModelStatusMonitoring = () => {
			if (statusMonitoringInterval) clearInterval(statusMonitoringInterval);
			statusMonitoringInterval = setInterval(_asyncToGenerator(function* () {
				try {
					const response = yield chrome.runtime.sendMessage({ type: "get_model_status" });
					if (response && response.success) {
						const status = response.status;
						modelInitializationStatus.value = status.initializationStatus || "idle";
						modelDownloadProgress.value = status.downloadProgress || 0;
						isModelDownloading.value = status.isDownloading || false;
						if (status.initializationStatus === "error") {
							modelErrorMessage.value = status.errorMessage || getMessage("modelFailedStatus");
							modelErrorType.value = status.errorType || "unknown";
						} else {
							modelErrorMessage.value = "";
							modelErrorType.value = "";
						}
						yield saveModelState();
						if (status.initializationStatus === "ready" || status.initializationStatus === "error") stopModelStatusMonitoring();
					}
				} catch (error) {
					console.error("获取模型状态失败:", error);
				}
			}), 1e3);
		};
		const stopModelStatusMonitoring = () => {
			if (statusMonitoringInterval) {
				clearInterval(statusMonitoringInterval);
				statusMonitoringInterval = null;
			}
		};
		const startSemanticEngineStatusPolling = () => {
			if (semanticEngineStatusPollingInterval) clearInterval(semanticEngineStatusPollingInterval);
			semanticEngineStatusPollingInterval = setInterval(_asyncToGenerator(function* () {
				try {
					yield checkSemanticEngineStatus();
				} catch (error) {
					console.error("Semantic engine status polling failed:", error);
				}
			}), 2e3);
		};
		const stopSemanticEngineStatusPolling = () => {
			if (semanticEngineStatusPollingInterval) {
				clearInterval(semanticEngineStatusPollingInterval);
				semanticEngineStatusPollingInterval = null;
			}
		};
		const refreshStorageStats = function() {
			var _ref33 = _asyncToGenerator(function* () {
				if (isRefreshingStats.value) return;
				isRefreshingStats.value = true;
				try {
					console.log("🔄 Refreshing storage statistics...");
					const response = yield chrome.runtime.sendMessage({ type: "get_storage_stats" });
					if (response && response.success) {
						storageStats.value = {
							indexedPages: response.stats.indexedPages || 0,
							totalDocuments: response.stats.totalDocuments || 0,
							totalTabs: response.stats.totalTabs || 0,
							indexSize: response.stats.indexSize || 0,
							isInitialized: response.stats.isInitialized || false
						};
						console.log("✅ Storage stats refreshed:", storageStats.value);
					} else {
						console.error("❌ Failed to get storage stats:", response === null || response === void 0 ? void 0 : response.error);
						storageStats.value = {
							indexedPages: 0,
							totalDocuments: 0,
							totalTabs: 0,
							indexSize: 0,
							isInitialized: false
						};
					}
				} catch (error) {
					console.error("❌ Error refreshing storage stats:", error);
					storageStats.value = {
						indexedPages: 0,
						totalDocuments: 0,
						totalTabs: 0,
						indexSize: 0,
						isInitialized: false
					};
				} finally {
					isRefreshingStats.value = false;
				}
			});
			return function refreshStorageStats() {
				return _ref33.apply(this, arguments);
			};
		}();
		const hideClearDataConfirmation = () => {
			showClearConfirmation.value = false;
		};
		const confirmClearAllData = function() {
			var _ref34 = _asyncToGenerator(function* () {
				if (isClearingData.value) return;
				isClearingData.value = true;
				clearDataProgress.value = getMessage("clearingStatus");
				try {
					console.log("🗑️ Starting to clear all data...");
					const response = yield chrome.runtime.sendMessage({ type: "clear_all_data" });
					if (response && response.success) {
						clearDataProgress.value = getMessage("dataClearedNotification");
						console.log("✅ All data cleared successfully");
						yield refreshStorageStats();
						setTimeout(() => {
							clearDataProgress.value = "";
							hideClearDataConfirmation();
						}, 2e3);
					} else throw new Error((response === null || response === void 0 ? void 0 : response.error) || "Failed to clear data");
				} catch (error) {
					console.error("❌ Failed to clear all data:", error);
					clearDataProgress.value = `Failed to clear data: ${(error === null || error === void 0 ? void 0 : error.message) || "Unknown error"}`;
					setTimeout(() => {
						clearDataProgress.value = "";
					}, 5e3);
				} finally {
					isClearingData.value = false;
				}
			});
			return function confirmClearAllData() {
				return _ref34.apply(this, arguments);
			};
		}();
		const switchModel = function() {
			var _ref35 = _asyncToGenerator(function* (newModel) {
				console.log(`🔄 switchModel called with newModel: ${newModel}`);
				if (isModelSwitching.value) {
					console.log("⏸️ Model switch already in progress, skipping");
					return;
				}
				const isSameModel = newModel === currentModel.value;
				const currentModelInfo = currentModel.value ? getModelInfo(currentModel.value) : getModelInfo("multilingual-e5-small");
				const newModelInfo = getModelInfo(newModel);
				const isDifferentDimension = currentModelInfo.dimension !== newModelInfo.dimension;
				console.log(`📊 Switch analysis:`);
				console.log(`   - Same model: ${isSameModel} (${currentModel.value} -> ${newModel})`);
				console.log(`   - Current dimension: ${currentModelInfo.dimension}, New dimension: ${newModelInfo.dimension}`);
				console.log(`   - Different dimension: ${isDifferentDimension}`);
				if (isSameModel && !isDifferentDimension) {
					console.log("✅ Same model and dimension - no need to switch");
					return;
				}
				const switchReasons = [];
				if (!isSameModel) switchReasons.push("different model");
				if (isDifferentDimension) switchReasons.push("different dimension");
				console.log(`🚀 Switching model due to: ${switchReasons.join(", ")}`);
				console.log(`📋 Model: ${currentModel.value} (${currentModelInfo.dimension}D) -> ${newModel} (${newModelInfo.dimension}D)`);
				isModelSwitching.value = true;
				modelSwitchProgress.value = getMessage("switchingModelStatus");
				modelInitializationStatus.value = "downloading";
				modelDownloadProgress.value = 0;
				isModelDownloading.value = true;
				try {
					yield saveModelPreference(newModel);
					yield saveVersionPreference("quantized");
					yield saveModelState();
					modelSwitchProgress.value = getMessage("semanticEngineInitializingStatus");
					startModelStatusMonitoring();
					const response = yield chrome.runtime.sendMessage({
						type: "switch_semantic_model",
						modelPreset: newModel,
						modelVersion: "quantized",
						modelDimension: newModelInfo.dimension,
						previousDimension: currentModelInfo.dimension
					});
					if (response && response.success) {
						currentModel.value = newModel;
						modelSwitchProgress.value = getMessage("successNotification");
						console.log("模型切换成功:", newModel, "version: quantized", "dimension:", newModelInfo.dimension);
						modelInitializationStatus.value = "ready";
						isModelDownloading.value = false;
						yield saveModelState();
						setTimeout(() => {
							modelSwitchProgress.value = "";
						}, 2e3);
					} else throw new Error((response === null || response === void 0 ? void 0 : response.error) || "Model switch failed");
				} catch (error) {
					console.error("模型切换失败:", error);
					modelSwitchProgress.value = `Model switch failed: ${(error === null || error === void 0 ? void 0 : error.message) || "Unknown error"}`;
					modelInitializationStatus.value = "error";
					isModelDownloading.value = false;
					const errorMessage = (error === null || error === void 0 ? void 0 : error.message) || "未知错误";
					if (errorMessage.includes("network") || errorMessage.includes("fetch") || errorMessage.includes("timeout")) {
						modelErrorType.value = "network";
						modelErrorMessage.value = getMessage("networkErrorMessage");
					} else if (errorMessage.includes("corrupt") || errorMessage.includes("invalid") || errorMessage.includes("format")) {
						modelErrorType.value = "file";
						modelErrorMessage.value = getMessage("modelCorruptedErrorMessage");
					} else {
						modelErrorType.value = "unknown";
						modelErrorMessage.value = errorMessage;
					}
					yield saveModelState();
					setTimeout(() => {
						modelSwitchProgress.value = "";
					}, 8e3);
				} finally {
					isModelSwitching.value = false;
				}
			});
			return function switchModel(_x10) {
				return _ref35.apply(this, arguments);
			};
		}();
		const setupServerStatusListener = () => {
			const onMessage = (message) => {
				if (message.type === BACKGROUND_MESSAGE_TYPES.SERVER_STATUS_CHANGED && message.payload) {
					serverStatus.value = message.payload;
					if (message.payload.nativeConnected === false) nativeConnectionStatus.value = "disconnected";
					else if (message.payload.nativeConnected === true) nativeConnectionStatus.value = "connected";
					console.log("Server status updated:", message.payload);
				}
				if (message.type === BACKGROUND_MESSAGE_TYPES.RR_FLOWS_CHANGED) loadFlows();
			};
			chrome.runtime.onMessage.addListener(onMessage);
			window.__rr_popup_onMessage = onMessage;
		};
		onMounted(_asyncToGenerator(function* () {
			yield initTheme();
			yield loadPortPreference();
			yield loadForceFocusPreference();
			yield loadBackgroundModePreference();
			yield loadDedicatedWindowPreference();
			yield loadSitePermissionToggles();
			yield loadModelPreference();
			yield checkNativeConnection();
			yield checkServerStatus();
			yield refreshStorageStats();
			yield loadCacheStats();
			yield loadFlows();
			try {
				const [tab] = yield chrome.tabs.query({
					active: true,
					currentWindow: true
				});
				currentTabUrl.value = (tab === null || tab === void 0 ? void 0 : tab.url) || "";
			} catch (_unused6) {}
			yield checkSemanticEngineStatus();
			setupServerStatusListener();
			try {
				const onChanged = (changes, area) => {
					try {
						if (area !== "local") return;
						if (Object.prototype.hasOwnProperty.call(changes || {}, "rr_flows")) loadFlows();
						if (Object.prototype.hasOwnProperty.call(changes || {}, "forceFocusOnToolCall")) {
							var _changes$FORCE_FOCUS_;
							forceFocusEnabled.value = ((_changes$FORCE_FOCUS_ = changes["forceFocusOnToolCall"]) === null || _changes$FORCE_FOCUS_ === void 0 ? void 0 : _changes$FORCE_FOCUS_.newValue) === true;
						}
						if (Object.prototype.hasOwnProperty.call(changes || {}, "backgroundWorkMode")) {
							var _changes$BACKGROUND_M;
							backgroundModeEnabled.value = ((_changes$BACKGROUND_M = changes["backgroundWorkMode"]) === null || _changes$BACKGROUND_M === void 0 ? void 0 : _changes$BACKGROUND_M.newValue) !== false;
						}
						if (Object.prototype.hasOwnProperty.call(changes || {}, "dedicatedWorkWindow")) {
							var _changes$DEDICATED_WI;
							dedicatedWindowEnabled.value = ((_changes$DEDICATED_WI = changes["dedicatedWorkWindow"]) === null || _changes$DEDICATED_WI === void 0 ? void 0 : _changes$DEDICATED_WI.newValue) !== false;
						}
						if (Object.prototype.hasOwnProperty.call(changes || {}, "sitePermissionToggles")) loadSitePermissionToggles();
					} catch (_unused7) {}
				};
				chrome.storage.onChanged.addListener(onChanged);
				window.__rr_popup_onChanged = onChanged;
			} catch (_unused8) {}
		}));
		onUnmounted(() => {
			stopModelStatusMonitoring();
			stopSemanticEngineStatusPolling();
			try {
				var _chrome;
				const msgFn = window.__rr_popup_onMessage;
				if (msgFn && ((_chrome = chrome) === null || _chrome === void 0 || (_chrome = _chrome.runtime) === null || _chrome === void 0 || (_chrome = _chrome.onMessage) === null || _chrome === void 0 ? void 0 : _chrome.removeListener)) chrome.runtime.onMessage.removeListener(msgFn);
			} catch (_unused9) {}
			try {
				var _chrome2;
				const fn = window.__rr_popup_onChanged;
				if (fn && ((_chrome2 = chrome) === null || _chrome2 === void 0 || (_chrome2 = _chrome2.storage) === null || _chrome2 === void 0 || (_chrome2 = _chrome2.onChanged) === null || _chrome2 === void 0 ? void 0 : _chrome2.removeListener)) chrome.storage.onChanged.removeListener(fn);
			} catch (_unused10) {}
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "popup-container agent-theme",
				"data-agent-theme": unref(agentTheme)
			}, [
				withDirectives(createBaseVNode("div", _hoisted_2, [_cache[13] || (_cache[13] = createBaseVNode("div", { class: "header" }, [createBaseVNode("div", { class: "header-content" }, [createBaseVNode("h1", { class: "header-title" }, "ScaleMaker Chrome Mcp")])], -1)), createBaseVNode("div", _hoisted_3, [createBaseVNode("div", _hoisted_4, [createBaseVNode("h2", _hoisted_5, toDisplayString(unref(getMessage)("nativeServerConfigLabel")), 1), createBaseVNode("div", _hoisted_6, [
					createBaseVNode("div", _hoisted_7, [
						createBaseVNode("div", _hoisted_8, [createBaseVNode("p", _hoisted_9, toDisplayString(unref(getMessage)("runningStatusLabel")), 1), createBaseVNode("div", _hoisted_10, [
							createBaseVNode("label", {
								class: "force-focus-switch",
								title: forceFocusEnabled.value ? "강제 포커스 ON — MCP 도구 실행 시 Chrome 윈도우가 OS 앞으로 튀어나옴" : "강제 포커스 OFF — MCP 도구 실행 시 OS 포커스 가로채지 않음"
							}, [
								createBaseVNode("input", {
									type: "checkbox",
									class: "force-focus-switch__input",
									checked: forceFocusEnabled.value,
									"aria-label": forceFocusEnabled.value ? "강제 포커스 끄기" : "강제 포커스 켜기",
									onChange: toggleForceFocus
								}, null, 40, _hoisted_12),
								_cache[3] || (_cache[3] = createBaseVNode("span", { class: "force-focus-switch__label" }, "강제 포커스", -1)),
								createBaseVNode("span", { class: normalizeClass(["force-focus-switch__track", { "force-focus-switch__track--on": forceFocusEnabled.value }]) }, [..._cache[2] || (_cache[2] = [createBaseVNode("span", { class: "force-focus-switch__thumb" }, null, -1)])], 2)
							], 8, _hoisted_11),
							createBaseVNode("label", _hoisted_13, [
								createBaseVNode("input", {
									type: "checkbox",
									class: "force-focus-switch__input",
									checked: backgroundModeEnabled.value,
									"aria-label": backgroundModeEnabled.value ? "백그라운드 작업 끄기" : "백그라운드 작업 켜기",
									onChange: toggleBackgroundMode
								}, null, 40, _hoisted_14),
								_cache[5] || (_cache[5] = createBaseVNode("span", { class: "force-focus-switch__label" }, "백그라운드 작업", -1)),
								createBaseVNode("span", { class: normalizeClass(["force-focus-switch__track", { "force-focus-switch__track--on": backgroundModeEnabled.value }]) }, [..._cache[4] || (_cache[4] = [createBaseVNode("span", { class: "force-focus-switch__thumb" }, null, -1)])], 2)
							]),
							createBaseVNode("label", _hoisted_15, [
								createBaseVNode("input", {
									type: "checkbox",
									class: "force-focus-switch__input",
									checked: dedicatedWindowEnabled.value,
									"aria-label": dedicatedWindowEnabled.value ? "전용 작업 창 끄기" : "전용 작업 창 켜기",
									onChange: toggleDedicatedWindow
								}, null, 40, _hoisted_16),
								_cache[7] || (_cache[7] = createBaseVNode("span", { class: "force-focus-switch__label" }, "전용 작업 창", -1)),
								createBaseVNode("span", { class: normalizeClass(["force-focus-switch__track", { "force-focus-switch__track--on": dedicatedWindowEnabled.value }]) }, [..._cache[6] || (_cache[6] = [createBaseVNode("span", { class: "force-focus-switch__thumb" }, null, -1)])], 2)
							])
						])]),
						createBaseVNode("div", _hoisted_17, [createBaseVNode("span", { class: normalizeClass(["status-dot", getStatusClass()]) }, null, 2), createBaseVNode("span", _hoisted_18, toDisplayString(getStatusText()), 1)]),
						serverStatus.value.lastUpdated ? (openBlock(), createElementBlock("div", _hoisted_19, toDisplayString(unref(getMessage)("lastUpdatedLabel")) + " " + toDisplayString(new Date(serverStatus.value.lastUpdated).toLocaleTimeString()), 1)) : createCommentVNode("", true)
					]),
					showMcpConfig.value ? (openBlock(), createElementBlock("div", _hoisted_20, [
						_cache[8] || (_cache[8] = createBaseVNode("div", { class: "mcp-config-header" }, [createBaseVNode("p", { class: "mcp-config-label" }, "⚡ Claude Code 자동 등록 prompt")], -1)),
						_cache[9] || (_cache[9] = createBaseVNode("p", { class: "claude-prompt-hint" }, [
							createTextVNode(" 터미널의 "),
							createBaseVNode("code", null, "claude"),
							createTextVNode(" 에 붙여넣으면 "),
							createBaseVNode("code", null, ".mcp.json"),
							createTextVNode(" 자동 등록 ")
						], -1)),
						createBaseVNode("div", _hoisted_21, [createBaseVNode("button", {
							class: "copy-config-button copy-config-button--floating",
							onClick: copyClaudePrompt
						}, toDisplayString(claudePromptCopyText.value), 1), createBaseVNode("pre", _hoisted_22, toDisplayString(claudePromptText.value), 1)])
					])) : createCommentVNode("", true),
					createBaseVNode("div", _hoisted_23, [createBaseVNode("label", _hoisted_24, toDisplayString(unref(getMessage)("connectionPortLabel")), 1), createBaseVNode("input", {
						type: "text",
						id: "port",
						value: nativeServerPort.value,
						onInput: updatePort,
						class: "port-input"
					}, null, 40, _hoisted_25)]),
					createBaseVNode("button", {
						class: "connect-button",
						disabled: isConnecting.value,
						onClick: testNativeConnection
					}, [createVNode(unref(BoltIcon_default)), createBaseVNode("span", null, toDisplayString(isConnecting.value ? unref(getMessage)("connectingStatus") : nativeConnectionStatus.value === "connected" ? unref(getMessage)("disconnectButton") : unref(getMessage)("connectButton")), 1)], 8, _hoisted_26),
					createVNode(ForceReconnect_default, {
						port: Number(nativeServerPort.value) || 12320,
						onReconnected: handleReconnected
					}, null, 8, ["port"]),
					createVNode(Diagnostic_default, { port: Number(nativeServerPort.value) || 12320 }, null, 8, ["port"])
				])]), createBaseVNode("div", _hoisted_27, [_cache[12] || (_cache[12] = createBaseVNode("h2", { class: "section-title" }, "권한 설정", -1)), createBaseVNode("div", _hoisted_28, [_cache[11] || (_cache[11] = createBaseVNode("p", { class: "site-perms-hint" }, " AI 가 아래 권한을 사용하려 할 때, 토글이 OFF 면 사용자에게 확인합니다. ", -1)), createBaseVNode("div", _hoisted_29, [(openBlock(), createElementBlock(Fragment, null, renderList(SITE_PERMISSION_ITEMS, (item) => {
					return createBaseVNode("div", {
						key: item.key,
						class: "site-perms-row-wrap"
					}, [createBaseVNode("label", _hoisted_30, [createBaseVNode("span", _hoisted_31, [createBaseVNode("span", _hoisted_32, toDisplayString(item.icon), 1), createBaseVNode("span", null, toDisplayString(item.label), 1)]), createBaseVNode("span", _hoisted_33, [createBaseVNode("button", {
						type: "button",
						class: "site-perms-os-btn",
						title: `OS 시스템 설정에서 ${item.label} 권한 열기`,
						"aria-label": `OS 시스템 설정에서 ${item.label} 권한 열기`,
						onClick: withModifiers(($event) => openOSPermission(item.key), ["stop", "prevent"])
					}, " ⚙ ", 8, _hoisted_34), createBaseVNode("span", _hoisted_35, [createBaseVNode("input", {
						type: "checkbox",
						class: "force-focus-switch__input",
						checked: sitePermissionToggles.value[item.key],
						"aria-label": `${item.label} 토글`,
						onChange: ($event) => toggleSitePermission(item.key)
					}, null, 40, _hoisted_36), createBaseVNode("span", { class: normalizeClass(["force-focus-switch__track", { "force-focus-switch__track--on": sitePermissionToggles.value[item.key] }]) }, [..._cache[10] || (_cache[10] = [createBaseVNode("span", { class: "force-focus-switch__thumb" }, null, -1)])], 2)])])])]);
				}), 64))])])])])], 512), [[vShow, currentView.value === "home"]]),
				withDirectives(createVNode(LocalModelPage_default, {
					"semantic-engine-status": semanticEngineStatus.value,
					"is-semantic-engine-initializing": isSemanticEngineInitializing.value,
					"semantic-engine-init-progress": semanticEngineInitProgress.value,
					"semantic-engine-last-updated": semanticEngineLastUpdated.value,
					"available-models": availableModels.value,
					"current-model": currentModel.value,
					"is-model-switching": isModelSwitching.value,
					"is-model-downloading": isModelDownloading.value,
					"model-download-progress": modelDownloadProgress.value,
					"model-initialization-status": modelInitializationStatus.value,
					"model-error-message": modelErrorMessage.value,
					"model-error-type": modelErrorType.value,
					"storage-stats": storageStats.value,
					"is-clearing-data": isClearingData.value,
					"clear-data-progress": clearDataProgress.value,
					"cache-stats": cacheStats.value,
					"is-managing-cache": isManagingCache.value,
					onBack: _cache[0] || (_cache[0] = ($event) => currentView.value = "home"),
					onInitializeSemanticEngine: initializeSemanticEngine,
					onSwitchModel: switchModel,
					onRetryModelInitialization: retryModelInitialization,
					onShowClearConfirmation: _cache[1] || (_cache[1] = ($event) => showClearConfirmation.value = true),
					onCleanupCache: cleanupCache,
					onClearAllCache: clearAllCache
				}, null, 8, [
					"semantic-engine-status",
					"is-semantic-engine-initializing",
					"semantic-engine-init-progress",
					"semantic-engine-last-updated",
					"available-models",
					"current-model",
					"is-model-switching",
					"is-model-downloading",
					"model-download-progress",
					"model-initialization-status",
					"model-error-message",
					"model-error-type",
					"storage-stats",
					"is-clearing-data",
					"clear-data-progress",
					"cache-stats",
					"is-managing-cache"
				]), [[vShow, currentView.value === "local-model"]]),
				createVNode(ConfirmDialog_default, {
					visible: showClearConfirmation.value,
					title: unref(getMessage)("confirmClearDataTitle"),
					message: unref(getMessage)("clearDataWarningMessage"),
					items: [
						unref(getMessage)("clearDataList1"),
						unref(getMessage)("clearDataList2"),
						unref(getMessage)("clearDataList3")
					],
					warning: unref(getMessage)("clearDataIrreversibleWarning"),
					icon: "⚠️",
					"confirm-text": unref(getMessage)("confirmClearButton"),
					"cancel-text": unref(getMessage)("cancelButton"),
					"confirming-text": unref(getMessage)("clearingStatus"),
					"is-confirming": isClearingData.value,
					onConfirm: confirmClearAllData,
					onCancel: hideClearDataConfirmation
				}, null, 8, [
					"visible",
					"title",
					"message",
					"items",
					"warning",
					"confirm-text",
					"cancel-text",
					"confirming-text",
					"is-confirming"
				]),
				createVNode(Transition, { name: "toast" }, {
					default: withCtx(() => [comingSoonToast.value.show ? (openBlock(), createElementBlock("div", _hoisted_37, [_cache[14] || (_cache[14] = createBaseVNode("svg", {
						class: "toast-icon",
						viewBox: "0 0 24 24",
						fill: "none",
						stroke: "currentColor",
						"stroke-width": "2"
					}, [createBaseVNode("circle", {
						cx: "12",
						cy: "12",
						r: "10"
					}), createBaseVNode("path", {
						d: "M12 6v6l4 2",
						"stroke-linecap": "round",
						"stroke-linejoin": "round"
					})], -1)), createBaseVNode("span", null, toDisplayString(comingSoonToast.value.feature) + " 기능 개발 중, 출시 예정", 1)])) : createCommentVNode("", true)]),
					_: 1
				})
			], 8, _hoisted_1);
		};
	}
}), [["__scopeId", "data-v-1f08d71a"]]);
//#endregion
//#region entrypoints/popup/main.ts
preloadAgentTheme().then(() => {
	chrome.runtime.sendMessage({ type: NativeMessageType.ENSURE_NATIVE }).catch(() => {});
	createApp(App_default).mount("#app");
});
//#endregion
