import { n as init_asyncToGenerator, t as _asyncToGenerator } from "./asyncToGenerator-D0fCMItH.js";
import { Z as ref, _ as createStaticVNode, at as toDisplayString, b as defineComponent, f as createBaseVNode, h as createElementBlock, it as normalizeStyle, j as openBlock, m as createCommentVNode, r as createApp, rt as normalizeClass, t as _plugin_vue_export_helper_default, v as createTextVNode } from "./_plugin-vue_export-helper-WBN59Mux.js";
/* empty css                  */
/* empty css                    */
//#region entrypoints/welcome/App.vue?vue&type=script&setup=true&lang.ts
init_asyncToGenerator();
var _hoisted_1 = { class: "agent-theme welcome-root" };
var _hoisted_2 = { class: "min-h-screen flex flex-col" };
var _hoisted_3 = { class: "welcome-header flex-none px-6 py-5" };
var _hoisted_4 = { class: "max-w-3xl mx-auto flex items-center justify-between gap-4" };
var _hoisted_5 = { class: "flex items-center gap-3 min-w-0" };
var _hoisted_6 = {
	class: "welcome-icon w-10 h-10 flex items-center justify-center flex-shrink-0",
	"aria-hidden": "true"
};
var _hoisted_7 = {
	class: "w-6 h-6",
	style: { color: "var(--ac-accent)" },
	fill: "none",
	viewBox: "0 0 24 24",
	stroke: "currentColor"
};
var _hoisted_8 = { class: "flex-1 px-6 py-8" };
var _hoisted_9 = { class: "max-w-3xl mx-auto space-y-6" };
var _hoisted_10 = { class: "welcome-card p-2" };
var _hoisted_11 = { class: "welcome-tabs grid grid-cols-2 gap-2" };
var _hoisted_12 = {
	key: 0,
	class: "welcome-card welcome-card--primary p-6"
};
var _hoisted_13 = { class: "welcome-checklist mt-3 space-y-1.5 text-sm" };
var _hoisted_14 = { class: "welcome-code" };
var _hoisted_15 = {
	class: "mt-6 pt-5",
	style: { borderTop: "var(--ac-border-width) solid var(--ac-border)" }
};
var _hoisted_16 = { class: "mt-4 space-y-4 welcome-steps" };
var _hoisted_17 = { class: "welcome-step" };
var _hoisted_18 = { class: "min-w-0" };
var _hoisted_19 = { class: "welcome-command-row welcome-command-row--prompt mt-3" };
var _hoisted_20 = {
	class: "welcome-code text-xs break-all",
	style: {
		"white-space": "pre-wrap",
		"margin": "0"
	}
};
var _hoisted_21 = {
	key: 1,
	class: "welcome-card welcome-card--primary p-6"
};
var _hoisted_22 = {
	class: "mt-6 pt-5",
	style: { borderTop: "var(--ac-border-width) solid var(--ac-border)" }
};
var _hoisted_23 = { class: "mt-4 space-y-4 welcome-steps" };
var _hoisted_24 = { class: "welcome-step" };
var _hoisted_25 = { class: "min-w-0" };
var _hoisted_26 = { class: "welcome-command-row mt-3 flex items-center justify-between gap-3 px-4 py-3" };
var _hoisted_27 = { class: "welcome-code text-sm break-all" };
var _hoisted_28 = { class: "welcome-step" };
var _hoisted_29 = { class: "min-w-0" };
var _hoisted_30 = { class: "welcome-command-row welcome-command-row--prompt mt-3" };
var _hoisted_31 = {
	class: "welcome-code text-xs break-all",
	style: {
		"white-space": "pre-wrap",
		"margin": "0"
	}
};
//#endregion
//#region entrypoints/welcome/main.ts
createApp(/* @__PURE__ */ _plugin_vue_export_helper_default(/* @__PURE__ */ defineComponent({
	__name: "App",
	setup(__props) {
		const COMMANDS = {
			npmInstall: "npm install -g mcp-chrome-scalemaker-bridge",
			claudePrompt: `지금 working dir (이 프로젝트 폴더) 의 .mcp.json 에 우리 chrome MCP (mcp-chrome-scalemaker) 를 등록해줘. ~/.claude.json 같은 전역 설정에는 손대지 마.

규칙:
- 이름: "chrome-mcp-stdio"
- transport: stdio (HTTP 안 씀)
- command: "node"
- args: ["<npm root -g 출력값>/mcp-chrome-scalemaker-bridge/dist/mcp/mcp-server-stdio.js"]
- env: { "CHROME_PORT": "12320" }

먼저 \`npm root -g\` 를 bash 로 실행해서 실제 경로 얻고, 그 다음에 working dir 의 .mcp.json (없으면 신설) 의 mcpServers.chrome-mcp-stdio 만 추가/갱신해줘. 기존 다른 server 항목은 보존.

등록이 끝나면 아래 절차도 함께 안내해줘:
1. Claude Code 를 Ctrl+C 두 번으로 종료 후 다시 실행 (mcp 서버 재로드)
2. \`/mcp\` 입력해서 chrome-mcp-stdio 가 connected 상태인지 확인
3. 확인 후 Esc 로 빠져나오기`,
			repoUrl: "https://github.com/scalemaker-ship-it/mcp-chrome-scalemaker",
			extensionId: "aogfhfajjknomcnmlkbjmihjbknlhbbi",
			chromeExtensions: "chrome://extensions",
			extensionPath: `~/Downloads/mcp-chrome-scalemaker-extension-v${chrome.runtime.getManifest().version}/`
		};
		const copiedKey = ref(null);
		const activePath = ref("npm");
		function copyLabel(key) {
			return copiedKey.value === key ? "✅ 복사됨" : "복사하기";
		}
		function copyColor(key) {
			return copiedKey.value === key ? "var(--ac-success)" : "var(--ac-text-muted)";
		}
		function copyCommand(_x) {
			return _copyCommand.apply(this, arguments);
		}
		function _copyCommand() {
			_copyCommand = _asyncToGenerator(function* (key) {
				try {
					yield navigator.clipboard.writeText(COMMANDS[key]);
					copiedKey.value = key;
					window.setTimeout(() => {
						if (copiedKey.value === key) copiedKey.value = null;
					}, 2e3);
				} catch (err) {
					console.error("Failed to copy:", err);
					copiedKey.value = null;
				}
			});
			return _copyCommand.apply(this, arguments);
		}
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", _hoisted_1, [createBaseVNode("div", _hoisted_2, [createBaseVNode("header", _hoisted_3, [createBaseVNode("div", _hoisted_4, [createBaseVNode("div", _hoisted_5, [createBaseVNode("div", _hoisted_6, [(openBlock(), createElementBlock("svg", _hoisted_7, [..._cache[5] || (_cache[5] = [createBaseVNode("path", {
				"stroke-linecap": "round",
				"stroke-linejoin": "round",
				"stroke-width": "2",
				d: "M13 10V3L4 14h7v7l9-11h-7z"
			}, null, -1)])]))]), _cache[6] || (_cache[6] = createBaseVNode("div", { class: "min-w-0" }, [createBaseVNode("h1", { class: "welcome-title text-lg font-medium tracking-tight truncate" }, " ScaleMaker Chrome Mcp "), createBaseVNode("p", { class: "welcome-muted text-sm truncate" }, " 확장 설치 후 남은 마지막 단계입니다. ")], -1))])])]), createBaseVNode("main", _hoisted_8, [createBaseVNode("div", _hoisted_9, [
				createBaseVNode("section", _hoisted_10, [createBaseVNode("div", _hoisted_11, [createBaseVNode("button", {
					class: normalizeClass(["welcome-tab px-4 py-3 text-sm font-medium", { "welcome-tab--active": activePath.value === "npm" }]),
					onClick: _cache[0] || (_cache[0] = ($event) => activePath.value = "npm")
				}, [..._cache[7] || (_cache[7] = [
					createBaseVNode("div", { class: "welcome-mono welcome-subtle text-[10px] uppercase tracking-widest" }, " Path A ", -1),
					createBaseVNode("div", { class: "welcome-title mt-0.5" }, "npm 명령어로 설치", -1),
					createBaseVNode("div", { class: "welcome-muted text-xs mt-0.5" }, [createBaseVNode("code", { class: "welcome-code" }, "npm install -g"), createTextVNode(" 로 깔았다면 ")], -1)
				])], 2), createBaseVNode("button", {
					class: normalizeClass(["welcome-tab px-4 py-3 text-sm font-medium", { "welcome-tab--active": activePath.value === "zip" }]),
					onClick: _cache[1] || (_cache[1] = ($event) => activePath.value = "zip")
				}, [..._cache[8] || (_cache[8] = [
					createBaseVNode("div", { class: "welcome-mono welcome-subtle text-[10px] uppercase tracking-widest" }, " Path B ", -1),
					createBaseVNode("div", { class: "welcome-title mt-0.5" }, "zip 으로 수동 설치", -1),
					createBaseVNode("div", { class: "welcome-muted text-xs mt-0.5" }, " GitHub Release 에서 zip 만 받았다면 ", -1)
				])], 2)])]),
				activePath.value === "npm" ? (openBlock(), createElementBlock("section", _hoisted_12, [
					_cache[17] || (_cache[17] = createBaseVNode("h2", { class: "welcome-title text-xl font-medium" }, " npm 으로 설치한 경우 — 거의 다 끝났습니다 ", -1)),
					_cache[18] || (_cache[18] = createBaseVNode("p", { class: "welcome-muted text-sm mt-2" }, [createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "npm install -g mcp-chrome-scalemaker-bridge"), createTextVNode(" 가 postinstall 에서 자동으로 처리한 것: ")], -1)),
					createBaseVNode("ul", _hoisted_13, [
						_cache[10] || (_cache[10] = createBaseVNode("li", null, "✅ Bridge 전역 설치", -1)),
						_cache[11] || (_cache[11] = createBaseVNode("li", null, [
							createTextVNode("✅ Native Messaging manifest 등록 ("),
							createBaseVNode("code", { class: "welcome-code" }, "com.chromemcpscalemaker.nativehost"),
							createTextVNode(")")
						], -1)),
						createBaseVNode("li", null, [_cache[9] || (_cache[9] = createTextVNode("✅ Extension zip 다운로드 → ", -1)), createBaseVNode("code", _hoisted_14, toDisplayString(COMMANDS.extensionPath), 1)])
					]),
					createBaseVNode("div", _hoisted_15, [
						_cache[15] || (_cache[15] = createBaseVNode("h3", { class: "welcome-title text-base font-medium" }, "마지막 단계 — Claude Code 에 등록", -1)),
						createBaseVNode("ol", _hoisted_16, [createBaseVNode("li", _hoisted_17, [_cache[14] || (_cache[14] = createBaseVNode("div", { class: "welcome-step-num" }, "1", -1)), createBaseVNode("div", _hoisted_18, [
							_cache[12] || (_cache[12] = createStaticVNode("<div class=\"welcome-title text-sm font-medium\" data-v-ba48e91e>Claude Code 에 등록</div><p class=\"welcome-muted text-sm mt-1\" data-v-ba48e91e> 아래 prompt 를 [복사하기] → 터미널의 <code class=\"welcome-code welcome-code-inline px-1 py-0.5\" data-v-ba48e91e>claude</code> 에 붙여넣기. Claude Code 가 <code class=\"welcome-code welcome-code-inline px-1 py-0.5\" data-v-ba48e91e>.mcp.json</code> 에 <code class=\"welcome-code welcome-code-inline px-1 py-0.5\" data-v-ba48e91e>chrome-mcp-stdio</code> 자동 등록. </p>", 2)),
							createBaseVNode("div", _hoisted_19, [createBaseVNode("button", {
								class: "welcome-mono welcome-copy-floating ac-btn",
								style: normalizeStyle({ color: copyColor("claudePrompt") }),
								onClick: _cache[2] || (_cache[2] = ($event) => copyCommand("claudePrompt"))
							}, toDisplayString(copyLabel("claudePrompt")), 5), createBaseVNode("pre", _hoisted_20, toDisplayString(COMMANDS.claudePrompt), 1)]),
							_cache[13] || (_cache[13] = createBaseVNode("p", { class: "welcome-subtle text-xs mt-2" }, [
								createTextVNode(" 등록 후 Claude Code 재시작 → "),
								createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "/mcp"),
								createTextVNode(" 로 활성 확인. ")
							], -1))
						])])]),
						_cache[16] || (_cache[16] = createBaseVNode("p", { class: "welcome-subtle text-xs mt-4" }, [
							createTextVNode(" troubleshooting 스킬 ( "),
							createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "~/.claude/skills/chrome-mcp-scalemaker-doctor/"),
							createTextVNode(" ) 도 npm 설치 시 자동 등록됩니다. 이후 \"MCP 안 돼\" 한 마디로 자동 진단·복구. ")
						], -1))
					])
				])) : createCommentVNode("", true),
				activePath.value === "zip" ? (openBlock(), createElementBlock("section", _hoisted_21, [
					_cache[28] || (_cache[28] = createBaseVNode("h2", { class: "welcome-title text-xl font-medium" }, " zip 으로 수동 설치한 경우 — Bridge 추가 설치 필요 ", -1)),
					_cache[29] || (_cache[29] = createBaseVNode("p", { class: "welcome-muted text-sm mt-2" }, [
						createTextVNode(" extension zip 만 받아서 Load unpacked 했다면, Native Messaging host (bridge) 는 "),
						createBaseVNode("strong", null, "아직 안 깔린 상태"),
						createTextVNode("입니다. Chrome 이 extension 과 통신할 수 없으니 bridge 설치 필수. ")
					], -1)),
					createBaseVNode("div", _hoisted_22, [
						_cache[26] || (_cache[26] = createBaseVNode("h3", { class: "welcome-title text-base font-medium" }, "남은 단계 — 2개", -1)),
						createBaseVNode("ol", _hoisted_23, [createBaseVNode("li", _hoisted_24, [_cache[22] || (_cache[22] = createBaseVNode("div", { class: "welcome-step-num" }, "1", -1)), createBaseVNode("div", _hoisted_25, [
							_cache[19] || (_cache[19] = createBaseVNode("div", { class: "welcome-title text-sm font-medium" }, " Bridge 설치 — Native Messaging manifest + troubleshooting 스킬 자동 등록 ", -1)),
							_cache[20] || (_cache[20] = createBaseVNode("p", { class: "welcome-muted text-sm mt-1" }, " 터미널에서: ", -1)),
							createBaseVNode("div", _hoisted_26, [createBaseVNode("code", _hoisted_27, toDisplayString(COMMANDS.npmInstall), 1), createBaseVNode("button", {
								class: "welcome-mono px-2 py-1 text-xs font-medium ac-btn flex-shrink-0",
								style: normalizeStyle({ color: copyColor("npmInstall") }),
								onClick: _cache[3] || (_cache[3] = ($event) => copyCommand("npmInstall"))
							}, toDisplayString(copyLabel("npmInstall")), 5)]),
							_cache[21] || (_cache[21] = createBaseVNode("p", { class: "welcome-subtle text-xs mt-2" }, [
								createTextVNode(" postinstall 이 자동으로 manifest 등록 + "),
								createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "com.chromemcpscalemaker.nativehost.json"),
								createTextVNode(" 배치. Node.js 20+ 필요 — "),
								createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "node -v"),
								createTextVNode(" 로 확인. ")
							], -1))
						])]), createBaseVNode("li", _hoisted_28, [_cache[25] || (_cache[25] = createBaseVNode("div", { class: "welcome-step-num" }, "2", -1)), createBaseVNode("div", _hoisted_29, [
							_cache[23] || (_cache[23] = createStaticVNode("<div class=\"welcome-title text-sm font-medium\" data-v-ba48e91e>Claude Code 에 등록</div><p class=\"welcome-muted text-sm mt-1\" data-v-ba48e91e> 아래 prompt 를 [복사하기] → 터미널의 <code class=\"welcome-code welcome-code-inline px-1 py-0.5\" data-v-ba48e91e>claude</code> 에 붙여넣기. Claude Code 가 <code class=\"welcome-code welcome-code-inline px-1 py-0.5\" data-v-ba48e91e>.mcp.json</code> 에 <code class=\"welcome-code welcome-code-inline px-1 py-0.5\" data-v-ba48e91e>chrome-mcp-stdio</code> 자동 등록. </p>", 2)),
							createBaseVNode("div", _hoisted_30, [createBaseVNode("button", {
								class: "welcome-mono welcome-copy-floating ac-btn",
								style: normalizeStyle({ color: copyColor("claudePrompt") }),
								onClick: _cache[4] || (_cache[4] = ($event) => copyCommand("claudePrompt"))
							}, toDisplayString(copyLabel("claudePrompt")), 5), createBaseVNode("pre", _hoisted_31, toDisplayString(COMMANDS.claudePrompt), 1)]),
							_cache[24] || (_cache[24] = createBaseVNode("p", { class: "welcome-subtle text-xs mt-2" }, [
								createTextVNode(" 등록 후 Claude Code 재시작 → "),
								createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "/mcp"),
								createTextVNode(" 로 활성 확인. ")
							], -1))
						])])]),
						_cache[27] || (_cache[27] = createBaseVNode("p", { class: "welcome-subtle text-xs mt-4" }, [
							createTextVNode(" troubleshooting 스킬 ( "),
							createBaseVNode("code", { class: "welcome-code welcome-code-inline px-1 py-0.5" }, "~/.claude/skills/chrome-mcp-scalemaker-doctor/"),
							createTextVNode(" ) 도 step 1 의 npm 설치 시 자동 등록됩니다. 이후 \"MCP 안 돼\" 한 마디로 자동 진단·복구. ")
						], -1))
					])
				])) : createCommentVNode("", true)
			])])])]);
		};
	}
}), [["__scopeId", "data-v-ba48e91e"]])).mount("#app");
//#endregion
